export function WaveDivider({ flip = false }: { flip?: boolean }) {
  return (
    <svg
      className={flip ? "wave-divider flip" : "wave-divider"}
      viewBox="0 0 1440 48"
      preserveAspectRatio="none"
      aria-hidden
    >
      <path
        fill="currentColor"
        d="M0,32 C240,48 480,8 720,24 C960,40 1200,16 1440,32 L1440,48 L0,48 Z"
      />
    </svg>
  )
}
