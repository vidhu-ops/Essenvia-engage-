#!/usr/bin/env node
/**
 * Regenerates public/images/products/skus/*.svg with clearer pack labels (brand + size).
 * Run: node scripts/enhance-sku-pack-art.mjs
 */
import { writeFileSync } from "fs"
import path from "path"
import { createRequire } from "module"
const require = createRequire(import.meta.url)
// Resolved at runtime via tsx (npm run enhance:sku-art)
const { catalogue } = require("../src/data/catalogue.ts")

const outDir = path.join(process.cwd(), "public/images/products/skus")

const formAccent = {
  Pods: "#FF6B35",
  ActionPacs: "#2D6A5A",
  Liquid: "#1E88E5",
  "Premoistened wipes": "#43A047",
  "Plastic bags": "#5D4037",
  "Liquid spray": "#8E24AA",
}

for (const p of catalogue) {
  const accent = formAccent[p.form] ?? "#2D6A5A"
  const title = p.brand.length > 12 ? p.brand : p.brand
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 320" fill="none">
  <rect width="320" height="320" rx="24" fill="#F5F0E8"/>
  <rect x="40" y="48" width="240" height="224" rx="20" fill="#fff" stroke="${accent}" stroke-width="3"/>
  <rect x="40" y="48" width="240" height="56" rx="20" fill="${accent}" opacity="0.12"/>
  <text x="160" y="92" text-anchor="middle" font-family="system-ui,sans-serif" font-size="22" font-weight="700" fill="${accent}">${escapeXml(title)}</text>
  <text x="160" y="150" text-anchor="middle" font-family="system-ui,sans-serif" font-size="16" font-weight="600" fill="#333">${escapeXml(p.name)}</text>
  <text x="160" y="188" text-anchor="middle" font-family="system-ui,sans-serif" font-size="20" font-weight="700" fill="#111">${escapeXml(p.netQuantity)}</text>
  <text x="160" y="218" text-anchor="middle" font-family="system-ui,sans-serif" font-size="13" fill="#666">${escapeXml(p.form)} · ${escapeXml(p.variant)}</text>
  <text x="160" y="252" text-anchor="middle" font-family="system-ui,sans-serif" font-size="11" fill="#999">${escapeXml(p.id)}</text>
</svg>
`
  writeFileSync(path.join(outDir, `${p.id}.svg`), svg)
  console.log("wrote", p.id)
}

function escapeXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
}
