import { randomUUID } from "crypto"
import { NextResponse } from "next/server"
import {
  saveSurveyRecord,
  listSurveyRecords,
  upsertRepScript,
  DatabaseNotConfiguredError,
  getStorageBackend,
} from "@/lib/db"
import {
  assertCatalogueProducts,
  surveySubmitSchema,
} from "@/lib/validate-survey"
import { notifySurveySubmitted } from "@/lib/notify-survey"
import { resolveSurveyAdminToken } from "@/lib/surveys-admin-token"
import type { SurveyPayload } from "@/types/survey"

function unauthorized() {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
}

export async function GET(request: Request) {
  const token = await resolveSurveyAdminToken()
  if (token) {
    const auth = request.headers.get("authorization")
    if (auth !== `Bearer ${token}`) return unauthorized()
  }
  try {
    const surveys = await listSurveyRecords(200)
    return NextResponse.json({
      count: surveys.length,
      storage: getStorageBackend(),
      surveys,
    })
  } catch (e) {
    if (e instanceof DatabaseNotConfiguredError) {
      return NextResponse.json({ error: e.message }, { status: 503 })
    }
    console.error(e)
    return NextResponse.json({ error: "Failed to list surveys" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  let raw: unknown
  try {
    raw = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 })
  }

  const parsed = surveySubmitSchema.safeParse(raw)
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 },
    )
  }

  const catalogueErrors = assertCatalogueProducts(parsed.data)
  if (catalogueErrors.length > 0) {
    return NextResponse.json(
      { error: "Invalid product references", details: catalogueErrors },
      { status: 400 },
    )
  }

  const payload: SurveyPayload = {
    ...parsed.data,
    id: randomUUID(),
    submittedAt: new Date().toISOString(),
  }

  try {
    await saveSurveyRecord(payload)
    if (parsed.data.talkTrack?.scriptText?.trim()) {
      await upsertRepScript(
        parsed.data.salesRep.code,
        parsed.data.talkTrack.scriptText,
        parsed.data.talkTrack.scriptFilename,
      )
    }
  } catch (e) {
    if (e instanceof DatabaseNotConfiguredError) {
      return NextResponse.json({ error: e.message }, { status: 503 })
    }
    console.error(e)
    return NextResponse.json(
      { error: "Failed to persist survey" },
      { status: 500 },
    )
  }

  const email = await notifySurveySubmitted(payload)

  return NextResponse.json({
    ok: true,
    id: payload.id,
    submittedAt: payload.submittedAt,
    storage: getStorageBackend(),
    email,
  })
}
