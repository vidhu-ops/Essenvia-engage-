export const essenviaHowItWorks = {
  headline: "How Essenvia works on this call",
  subline:
    "Think of this like taking a table order: tap items into the basket, note preferences, and we package one delivered box — no checkout on the visit.",
  points: [
    {
      title: "One box, one price",
      body: "Essential, Family, or Plus — transparent CAD pricing with delivery included across Canada.",
    },
    {
      title: "Built from this menu",
      body: "You add catalogue SKUs and any custom sizes. Follow-up questions capture usage and must-haves.",
    },
    {
      title: "Rhythm, not rush",
      body: "Household size and routines set quantities; the customer receives before they run out.",
    },
    {
      title: "No payment today",
      body: "Survey records preferences for fulfillment — payment and signup happen after the visit.",
    },
  ] as const,
}
