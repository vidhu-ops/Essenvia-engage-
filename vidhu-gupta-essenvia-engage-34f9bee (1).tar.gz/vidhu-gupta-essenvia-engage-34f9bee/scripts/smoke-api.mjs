#!/usr/bin/env node
/** Quick API smoke checks against BASE_URL (default http://127.0.0.1:4321). */
const base = process.env.BASE_URL ?? "http://127.0.0.1:4321"

const sampleSurvey = {
  household: {
    size: "3–4 people",
    laundryLoads: "4–6 loads",
    detergentFormat: "Pods",
    laundryBrand: "Tide",
    dishwasherLoads: "4–6 loads",
    restockPace: "Typical",
  },
  boxPlan: "standard",
  menuItems: [
    { productId: "tide-free-16", quantity: 1 },
    {
      productId: "custom-smoke-test",
      quantity: 2,
      custom: {
        category: "Paper goods",
        productName: "Toilet paper",
        sizeOrVariant: "24 mega rolls",
      },
    },
  ],
  categoryInterests: [
    { categoryId: "paper-goods", importance: "Regular use", preferredItems: "Soft 2-ply" },
  ],
  productAnswers: [
    { productId: "tide-free-16", usage: "Daily", priority: "Must have" },
    { productId: "custom-smoke-test", usage: "Weekly", priority: "Nice to have" },
  ],
  salesRep: { name: "Smoke Test", code: "REP-SMOKE" },
}

async function main() {
  const checks = []

  const health = await fetch(`${base}/api/health`)
  const healthJson = await health.json()
  checks.push({
    name: "GET /api/health",
    ok:
      (health.status === 200 && healthJson.status === "ok") ||
      (health.status === 503 && healthJson.status === "degraded"),
    detail: { http: health.status, ...healthJson },
  })

  const bad = await fetch(`${base}/api/surveys`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ salesRep: { name: "x", code: "y" } }),
  })
  checks.push({
    name: "POST /api/surveys invalid → 400",
    ok: bad.status === 400,
    detail: bad.status,
  })

  const good = await fetch(`${base}/api/surveys`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(sampleSurvey),
  })
  const goodBody = await good.json().catch(() => ({}))
  checks.push({
    name: "POST /api/surveys valid payload",
    ok: good.status === 201 || good.status === 503,
    detail: good.status === 503 ? "DB not configured (expected locally)" : goodBody.id ?? goodBody,
  })

  for (const c of checks) {
    console.log(c.ok ? "✓" : "✗", c.name, typeof c.detail === "object" ? JSON.stringify(c.detail) : c.detail)
  }
  if (!checks.every((c) => c.ok)) process.exit(1)
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
