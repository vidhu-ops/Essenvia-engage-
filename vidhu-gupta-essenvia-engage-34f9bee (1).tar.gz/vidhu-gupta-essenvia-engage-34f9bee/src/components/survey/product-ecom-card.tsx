"use client"

import Image from "next/image"
import { Minus, Plus, ShoppingCart } from "lucide-react"
import type { CatalogueProduct } from "@/data/catalogue"
import { getCatalogueProductPhoto } from "@/data/product-photos"
import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function ProductEcomCard({
  product,
  quantity,
  onAdd,
  onAdjust,
}: {
  product: CatalogueProduct
  quantity: number
  onAdd: () => void
  onAdjust: (delta: number) => void
}) {
  const photo = getCatalogueProductPhoto(product)

  return (
    <article className="ecom-product-card flex flex-col rounded-2xl border bg-white overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="relative aspect-square bg-[var(--cream)]">
        <Image
          src={photo}
          alt={`${product.brand} ${product.name}`}
          fill
          className="object-contain p-3 sm:p-4"
          sizes="(max-width: 640px) 45vw, 220px"
        />
        <Badge className="absolute top-2 left-2 bg-white/95 text-foreground shadow-sm">
          {product.form}
        </Badge>
      </div>
      <div className="flex flex-1 flex-col p-3 sm:p-4 gap-2">
        <p className="text-xs font-medium text-[var(--essenvia-teal)] uppercase tracking-wide">
          {product.brand}
        </p>
        <h3 className="text-base font-semibold leading-snug line-clamp-2">
          {product.name}
        </h3>
        <p className="text-sm text-muted-foreground">{product.netQuantity}</p>
        <p className="text-xs text-muted-foreground line-clamp-1">{product.variant}</p>
        <div className="mt-auto pt-2">
          {quantity > 0 ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                aria-label="Remove one"
                className={cn(buttonVariants({ size: "icon", variant: "outline" }), "survey-touch-icon")}
                onClick={() => onAdjust(-1)}
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="flex-1 text-center font-semibold tabular-nums">{quantity} in box</span>
              <button
                type="button"
                aria-label="Add one"
                className={cn(buttonVariants({ size: "default" }), "survey-touch-btn flex-1")}
                onClick={() => onAdjust(1)}
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              className={cn(buttonVariants({ className: "w-full" }), "survey-touch-btn gap-2")}
              onClick={onAdd}
            >
              <ShoppingCart className="h-4 w-4" /> Add to box
            </button>
          )}
        </div>
      </div>
    </article>
  )
}

export function ShowcaseEcomCard({
  title,
  brand,
  detail,
  image,
  quantity,
  onAdd,
  onAdjust,
}: {
  title: string
  brand?: string
  detail: string
  image: string
  quantity: number
  onAdd: () => void
  onAdjust: (delta: number) => void
}) {
  return (
    <article className="ecom-product-card flex flex-col rounded-2xl border border-dashed border-[var(--essenvia-sage)] bg-white overflow-hidden">
      <div className="relative aspect-square bg-[var(--cream)]">
        <Image src={image} alt={title} fill className="object-contain p-4" sizes="220px" />
        <Badge variant="outline" className="absolute top-2 left-2 bg-white/95">
          Request
        </Badge>
      </div>
      <div className="flex flex-1 flex-col p-3 sm:p-4 gap-2">
        {brand && (
          <p className="text-xs font-medium text-[var(--essenvia-teal)] uppercase tracking-wide">{brand}</p>
        )}
        <h3 className="text-base font-semibold leading-snug">{title}</h3>
        <p className="text-xs text-muted-foreground line-clamp-3">{detail}</p>
        <div className="mt-auto pt-2">
          {quantity > 0 ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                className={cn(buttonVariants({ size: "icon", variant: "outline" }), "survey-touch-icon")}
                onClick={() => onAdjust(-1)}
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="flex-1 text-center font-semibold tabular-nums">{quantity}</span>
              <button
                type="button"
                className={cn(buttonVariants(), "survey-touch-btn flex-1")}
                onClick={() => onAdjust(1)}
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button type="button" className={cn(buttonVariants({ variant: "secondary" }), "survey-touch-btn w-full")} onClick={onAdd}>
              Add request
            </button>
          )}
        </div>
      </div>
    </article>
  )
}
