import Link from "next/link"
import { SurveyWizard } from "@/components/survey/survey-wizard"

export const metadata = {
  title: "Customer survey | Essenvia",
  description: "Production household survey with verified catalogue SKUs.",
}

export default function SurveyPage() {
  return (
    <div className="site-theme theme-1 builder-page">
      <div className="announcement builder-announcement">
        <span>Essenvia field survey · {process.env.NODE_ENV === "production" ? "Production" : "Development"}</span>
        <Link href="/" style={{ color: "var(--orange-dark)" }}>
          Back to site
        </Link>
      </div>
      <header className="site-header">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between gap-3">
          <Link href="/" className="linked-logo">
            essenvia<span>+</span>
          </Link>
          <span style={{ fontSize: "0.8rem", color: "var(--ink-muted)" }}>Sales survey</span>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-3 sm:px-4 md:px-6 py-4 sm:py-6 md:py-8 survey-main">
        <SurveyWizard />
      </main>
    </div>
  )
}
