# Essenvia landing & sales survey

Production field survey and marketing site for **Essenvia** — category shop UI, 26 PDF-verified catalogue SKUs, Postgres surveys, Resend email.

## Start here (no GitHub yet)

**There is no GitHub repository until you create one.** Source of truth:

- **Code:** [cursor.com/codebase/vidhu-gupta/essenvia-engage](https://cursor.com/codebase/vidhu-gupta/essenvia-engage)
- **Live app:** [essenvia-survey.apps.grok.bot](https://essenvia-survey.apps.grok.bot/survey)
- **Full map (Vercel, Git mirror, env vars):** [docs/WHERE-EVERYTHING-LIVES.md](docs/WHERE-EVERYTHING-LIVES.md)

To get **GitHub + Vercel Git deploy**: use Cursor **Create repo**, or follow Option B in that doc.

## Deploy on Vercel (recommended)

### Option A — Claim this preview (fastest)

1. **If you already claimed the project:** Vercel → your **essenvia** project → **Deployments** → **Redeploy** (or connect Git to [vidhu-gupta/essenvia-engage](https://origin.cursor.com/vidhu-gupta/essenvia-engage) so pushes to `main` auto-deploy). Latest code is on `main` (category shop + photos).
2. **New preview (latest build, ~1 hour):** **https://sonic-violet-vluva4d.tmp.now** — [claim](https://vercel.com/claim-deployment?code=5c2e96f3-22b8-4978-9d64-fea7ea5054e5) only if you want a separate project.
2. Name the project (e.g. `essenvia-engage`) and attach it to your team.
3. Complete **Option B** steps 2–4 below (Postgres + env vars + redeploy).

If the claim link expires, run locally: `npx vercel deploy --temporary --yes` from this repo and use the new `claimUrl` from the CLI output.

### Option B — Import Git in Vercel

1. **Import** [vidhu-gupta/essenvia-engage](https://origin.cursor.com/vidhu-gupta/essenvia-engage) in [Vercel New Project](https://vercel.com/new) (Origin/GitHub, depending on what your Vercel account supports).
2. **Add Postgres storage**: Project → **Storage** → **Postgres** (Neon). Vercel injects `POSTGRES_URL` into the project.
3. **Email notifications**: Create a [Resend](https://resend.com) API key and add **`RESEND_API_KEY`** in Vercel → Settings → Environment Variables. Each saved survey emails **`careers@essenvia.ca`** (override with **`SURVEY_NOTIFY_TO`**). Set **`RESEND_FROM`** after you verify your domain (until then Resend allows `onboarding@resend.dev` for testing).
4. **Survey admin API**: `GET /api/surveys` requires `Authorization: Bearer <token>`. Set **`SURVEYS_ADMIN_TOKEN`** in Vercel/Cursor secrets to pin a token, or leave it unset — with Postgres linked, the app creates one in `app_settings`, emails **`careers@essenvia.ca`** once (when Resend is configured), and you can run `npm run admin:token` with `DATABASE_URL` to print it.
5. **Deploy**. The build runs `npm run verify:catalogue && next build` (see `vercel.json`).
6. **Verify**: open `https://<your-domain>/api/health` — should return `{ "status": "ok", "database": "postgres" }` (503 + `degraded` until Postgres is linked). Submit a test survey and confirm the inbox at careers@essenvia.ca.

### Smoke checks (local or deployed)

```bash
npm run verify:catalogue
npm run build
BASE_URL=https://your-domain.vercel.app npm run smoke:api
```

Survey submissions require a working database. Without Postgres, the site loads but `/api/surveys` returns **503** with setup instructions.

### Local development with production parity

```bash
cp .env.example .env.local
# Paste POSTGRES_URL from Vercel: `vercel env pull` or Neon console
npm install
npm run verify:catalogue
npm run dev
```

## Scripts

| Command | Purpose |
|---------|---------|
| `npm run dev` | Dev server on port 4321 |
| `npm run build` | Production build |
| `npm run verify:catalogue` | Assert 26 SKUs match catalogue PDF manifest |
| `npm run admin:token` | Print surveys admin bearer token (env or Postgres) |

## API

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/health` | Liveness + database check |
| `POST` | `/api/surveys` | Submit validated survey |
| `GET` | `/api/surveys` | List surveys (optional admin token) |
| `GET/PUT` | `/api/rep-scripts` | Talk track by sales code |

## Stack

Next.js 16, TypeScript, Tailwind v4, Postgres (`postgres`), Zod.

Catalogue source: `public/Essenvia-product-catalogue.pdf`
