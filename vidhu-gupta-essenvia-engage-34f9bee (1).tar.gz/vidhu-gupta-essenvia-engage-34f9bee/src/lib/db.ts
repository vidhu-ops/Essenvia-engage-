import postgres from "postgres"
import { readFileSync } from "fs"
import path from "path"
import type { SurveyPayload } from "@/types/survey"

export class DatabaseNotConfiguredError extends Error {
  constructor() {
    super(
      "Database is not configured. On Vercel: add a Postgres integration (Neon) from Storage. Locally: set POSTGRES_URL or DATABASE_URL in .env.local.",
    )
    this.name = "DatabaseNotConfiguredError"
  }
}

declare global {
  // eslint-disable-next-line no-var
  var __essenviaSql: ReturnType<typeof postgres> | undefined
  // eslint-disable-next-line no-var
  var __essenviaSchemaReady: Promise<void> | undefined
}

function connectionString(): string | undefined {
  return (
    process.env.POSTGRES_URL ??
    process.env.DATABASE_URL ??
    process.env.POSTGRES_URL_NON_POOLING
  )
}

export function getSql(): ReturnType<typeof postgres> {
  const url = connectionString()
  if (!url) throw new DatabaseNotConfiguredError()
  if (!global.__essenviaSql) {
    global.__essenviaSql = postgres(url, {
      max: 1,
      idle_timeout: 20,
      connect_timeout: 15,
      ssl: url.includes("localhost") ? false : "require",
      prepare: false,
    })
  }
  return global.__essenviaSql
}

export async function ensureSchema(): Promise<void> {
  if (!global.__essenviaSchemaReady) {
    global.__essenviaSchemaReady = (async () => {
      const sql = getSql()
      const initPath = path.join(process.cwd(), "scripts/sql/init.sql")
      const ddl = readFileSync(initPath, "utf-8")
      await sql.unsafe(ddl)
    })()
  }
  await global.__essenviaSchemaReady
}

export function getStorageBackend(): "postgres" | "unconfigured" {
  return connectionString() ? "postgres" : "unconfigured"
}

export async function saveSurveyRecord(payload: SurveyPayload): Promise<void> {
  await ensureSchema()
  const sql = getSql()
  await sql`
    INSERT INTO surveys (id, submitted_at, rep_name, rep_code, box_plan, payload_json)
    VALUES (
      ${payload.id},
      ${payload.submittedAt},
      ${payload.salesRep.name},
      ${payload.salesRep.code},
      ${payload.boxPlan},
      ${sql.json(payload)}
    )
  `
}

export async function listSurveyRecords(limit = 100): Promise<SurveyPayload[]> {
  await ensureSchema()
  const sql = getSql()
  const rows = await sql<{ payload_json: SurveyPayload | string }[]>`
    SELECT payload_json FROM surveys
    ORDER BY submitted_at DESC
    LIMIT ${limit}
  `
  return rows.map((r) => {
    const raw = r.payload_json
    if (typeof raw === "string") return JSON.parse(raw) as SurveyPayload
    return raw
  })
}

export async function upsertRepScript(
  repCode: string,
  scriptText: string,
  scriptFilename?: string,
): Promise<void> {
  await ensureSchema()
  const sql = getSql()
  const updatedAt = new Date().toISOString()
  await sql`
    INSERT INTO rep_scripts (rep_code, script_text, script_filename, updated_at)
    VALUES (${repCode}, ${scriptText}, ${scriptFilename ?? null}, ${updatedAt})
    ON CONFLICT (rep_code) DO UPDATE SET
      script_text = EXCLUDED.script_text,
      script_filename = EXCLUDED.script_filename,
      updated_at = EXCLUDED.updated_at
  `
}

export async function getRepScript(repCode: string): Promise<{
  scriptText: string
  scriptFilename: string | null
  updatedAt: string
} | null> {
  await ensureSchema()
  const sql = getSql()
  const rows = await sql<
    {
      script_text: string
      script_filename: string | null
      updated_at: Date
    }[]
  >`
    SELECT script_text, script_filename, updated_at
    FROM rep_scripts WHERE rep_code = ${repCode}
  `
  const row = rows[0]
  if (!row) return null
  return {
    scriptText: row.script_text,
    scriptFilename: row.script_filename,
    updatedAt: row.updated_at.toISOString(),
  }
}

export async function pingDatabase(): Promise<boolean> {
  if (!connectionString()) return false
  await ensureSchema()
  const sql = getSql()
  await sql`SELECT 1 AS ok`
  return true
}
