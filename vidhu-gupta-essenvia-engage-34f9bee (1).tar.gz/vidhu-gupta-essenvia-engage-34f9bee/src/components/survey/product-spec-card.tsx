"use client"

import Image from "next/image"
import { Minus, Plus } from "lucide-react"
import type { CatalogueProduct } from "@/data/catalogue"
import { getProductPackImage } from "@/data/product-images"
import { getProductSpecRows } from "@/lib/product-specs"
import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function ProductSpecCard({
  product,
  quantity,
  onAdd,
  onAdjust,
}: {
  product: CatalogueProduct
  quantity: number
  onAdd: () => void
  onAdjust: (delta: number) => void
}) {
  const img = getProductPackImage(product)
  const specs = getProductSpecRows(product)

  return (
    <article
      className={cn(
        "flex flex-col rounded-2xl border bg-white overflow-hidden transition-shadow hover:shadow-md",
        quantity > 0 && "ring-2 ring-[var(--essenvia-teal)] border-[var(--essenvia-teal)]/40",
      )}
    >
      <div className="grid sm:grid-cols-[140px_1fr] gap-0 sm:gap-4">
        <div className="relative aspect-[4/3] max-h-48 sm:max-h-none sm:aspect-auto sm:min-h-[180px] bg-[var(--cream)] border-b sm:border-b-0 sm:border-r border-[var(--sand)]">
          <Image
            src={img}
            alt=""
            fill
            className="object-contain p-3"
            sizes="(max-width: 640px) 100vw, 140px"
          />
          {quantity > 0 && (
            <span className="absolute top-2 right-2 rounded-full bg-[var(--essenvia-teal)] px-2 py-0.5 text-xs font-bold text-white">
              ×{quantity}
            </span>
          )}
        </div>
        <div className="p-4 flex flex-col gap-2 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary">{product.category}</Badge>
            <span className="text-xs text-muted-foreground font-mono">{product.id}</span>
          </div>
          <h3 className="text-base sm:text-lg font-semibold leading-snug">
            {product.brand} {product.name}
          </h3>
          <dl className="product-spec-grid grid grid-cols-[minmax(7rem,auto)_1fr] gap-x-3 gap-y-1.5 text-sm leading-snug">
            {specs
              .filter((s) => !["Catalogue SKU", "Brand", "Product line", "Category"].includes(s.label))
              .map((s) => (
                <div key={s.label} className="contents">
                  <dt className="text-muted-foreground">{s.label}</dt>
                  <dd className="font-medium">{s.value}</dd>
                </div>
              ))}
          </dl>
          <div className="mt-auto pt-3 flex items-center gap-2">
            {quantity > 0 ? (
              <>
                <button
                  type="button"
                  aria-label="Remove one"
                  className={cn(buttonVariants({ size: "icon", variant: "outline" }), "survey-touch-icon")}
                  onClick={() => onAdjust(-1)}
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="flex-1 text-center text-base font-semibold tabular-nums">{quantity} in basket</span>
                <button
                  type="button"
                  aria-label="Add one"
                  className={cn(buttonVariants({ size: "default", className: "flex-1" }), "survey-touch-btn")}
                  onClick={() => onAdjust(1)}
                >
                  <Plus className="h-4 w-4" /> Add
                </button>
              </>
            ) : (
              <button
                type="button"
                className={cn(buttonVariants({ className: "w-full" }), "survey-touch-btn")}
                onClick={onAdd}
              >
                Add this size to basket
              </button>
            )}
          </div>
        </div>
      </div>
    </article>
  )
}
