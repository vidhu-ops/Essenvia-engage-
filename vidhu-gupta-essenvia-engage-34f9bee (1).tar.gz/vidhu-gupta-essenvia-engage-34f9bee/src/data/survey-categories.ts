/** Extended categories beyond the verified PDF SKU list — captured on every visit. */
export const surveyCategoryTopics = [
  {
    id: "paper-goods",
    label: "Paper goods",
    examples: "Toilet paper, paper towels, tissues, napkins",
  },
  {
    id: "personal-care",
    label: "Personal care",
    examples: "Toothpaste, hand soap, shampoo, deodorant",
  },
  {
    id: "bathroom-cleaning",
    label: "Bathroom cleaning",
    examples: "Toilet bowl cleaner, shower spray, grout care",
  },
  {
    id: "kitchen-extras",
    label: "Kitchen extras",
    examples: "Sponges, scrubbers, foil, food storage bags",
  },
  {
    id: "home-essentials",
    label: "Home essentials",
    examples: "Air care, light bulbs, batteries, misc. cleaners",
  },
  {
    id: "trash-liners",
    label: "Trash & liners",
    examples: "Kitchen bags, outdoor bins, sizes we may not list in the menu",
  },
] as const

export type SurveyCategoryTopicId = (typeof surveyCategoryTopics)[number]["id"]

export const categoryImportanceOptions = [
  "Not needed",
  "Light use",
  "Regular use",
  "Heavy use",
  "Not discussed on visit",
] as const

/** Categories available when reps add a custom menu line (includes catalogue groups). */
export const customMenuCategoryOptions = [
  "Laundry",
  "Kitchen",
  "Home care",
  "Paper goods",
  "Personal care",
  "Bathroom cleaning",
  "Other",
] as const

export type CustomMenuCategory = (typeof customMenuCategoryOptions)[number]
