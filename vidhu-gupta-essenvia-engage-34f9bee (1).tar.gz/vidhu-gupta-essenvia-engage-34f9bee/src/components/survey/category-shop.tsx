"use client"

import Image from "next/image"
import { Minus, Plus, Search, ShoppingBasket } from "lucide-react"
import { useMemo, useState } from "react"
import { catalogueById } from "@/data/catalogue"
import {
  frequencyOptions,
  productsForShopCategory,
  shopCategories,
  showcasesForShopCategory,
  topicMeta,
  type ShopCategoryId,
} from "@/data/shop-categories"
import { categoryTabPhotos } from "@/data/product-photos"
import { getCatalogueProductPhoto } from "@/data/product-photos"
import { ProductEcomCard, ShowcaseEcomCard } from "@/components/survey/product-ecom-card"
import { OptionGrid } from "@/components/survey/option-grid"
import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { essenviaHowItWorks } from "@/data/essenvia-how-it-works"
import { CUSTOM_LINE_IMAGE } from "@/data/product-images"
import { catalogueSearchBlob } from "@/lib/product-specs"
import type { CategoryInterest, MenuLine } from "@/types/survey"
import { cn } from "@/lib/utils"

const laundryLoadOptions = ["1–3 loads", "4–6 loads", "7–9 loads", "10+ loads"]
const formatOptions = ["Pods", "Liquid", "Powder"]
const brandOptions = ["Tide", "Gain", "Persil", "No preference"]
const kitchenLoadOptions = ["1–3 loads", "4–6 loads", "7–9 loads"]
const paceOptions = ["Light", "Typical", "Fully stocked"]

type CategoryShopProps = {
  boxLabel: string
  menuItems: MenuLine[]
  onAdd: (productId: string) => void
  onAdjustQty: (productId: string, delta: number) => void
  onAddShowcase: (payload: {
    category: string
    productName: string
    brand?: string
    sizeOrVariant: string
    notes?: string
  }) => void
  search: string
  onSearchChange: (v: string) => void
  laundryLoads: string
  onLaundryLoads: (v: string) => void
  detergentFormat: string
  onDetergentFormat: (v: string) => void
  laundryBrand: string
  onLaundryBrand: (v: string) => void
  dishwasherLoads: string
  onDishwasherLoads: (v: string) => void
  restockPace: string
  onRestockPace: (v: string) => void
  categoryInterests: CategoryInterest[]
  onCategoryImportance: (topicId: string, value: string) => void
}

function BasketLine({
  line,
  onAdjust,
}: {
  line: MenuLine
  onAdjust: (delta: number) => void
}) {
  const product = catalogueById.get(line.productId)
  const title = product
    ? `${product.brand} ${product.name}`
    : line.custom?.productName ?? "Custom item"
  const sub = product ? product.netQuantity : line.custom?.sizeOrVariant

  return (
    <li className="flex gap-3 items-center py-2 border-b border-[var(--sand)] last:border-0">
      <div className="relative h-14 w-14 shrink-0 rounded-lg bg-[var(--cream)] overflow-hidden">
        <Image
          src={product ? getCatalogueProductPhoto(product) : CUSTOM_LINE_IMAGE}
          alt=""
          fill
          className="object-contain p-1"
          sizes="56px"
        />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{title}</p>
        <p className="text-xs text-muted-foreground truncate">{sub}</p>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          aria-label="Decrease"
          className={buttonVariants({ size: "icon", variant: "ghost", className: "h-8 w-8" })}
          onClick={() => onAdjust(-1)}
        >
          <Minus className="h-3.5 w-3.5" />
        </button>
        <span className="w-6 text-center text-sm font-semibold tabular-nums">{line.quantity}</span>
        <button
          type="button"
          aria-label="Increase"
          className={buttonVariants({ size: "icon", variant: "ghost", className: "h-8 w-8" })}
          onClick={() => onAdjust(1)}
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>
    </li>
  )
}

export function CategoryShop(props: CategoryShopProps) {
  const [active, setActive] = useState<ShopCategoryId>("laundry")
  const config = shopCategories.find((c) => c.id === active)!
  const products = productsForShopCategory(active)
  const showcases = showcasesForShopCategory(active)

  const filteredProducts = useMemo(() => {
    const q = props.search.trim().toLowerCase()
    if (!q) return products
    return products.filter((p) => catalogueSearchBlob(p).includes(q))
  }, [products, props.search])

  const basketCount = props.menuItems.reduce((n, m) => n + m.quantity, 0)
  const qtyMap = useMemo(
    () => new Map(props.menuItems.map((m) => [m.productId, m.quantity])),
    [props.menuItems],
  )

  const topicsForTab = config.topicIds.map((id) => topicMeta(id)).filter(Boolean)

  return (
    <div className="category-shop space-y-4" data-testid="category-shop">
      <div>
        <p className="text-sm font-medium text-[var(--essenvia-teal)]">Build the box</p>
        <h2 className="survey-step-title mt-1">Shop by category</h2>
        <p className="text-muted-foreground mt-2 text-base leading-relaxed">
          Tap a category, answer how often they use it, then add products with photos — like an online store.
        </p>
      </div>

      <nav
        className="category-tab-bar sticky top-0 z-20 -mx-1 px-1 py-2 bg-card/95 backdrop-blur border-b border-[var(--sand)]"
        aria-label="Product categories"
      >
        <div className="flex gap-2 overflow-x-auto pb-1 snap-x snap-mandatory">
          {shopCategories.map((tab) => {
            const count =
              tab.catalogueCategory === "Laundry"
                ? props.menuItems.filter((m) => catalogueById.get(m.productId)?.category === "Laundry").length
                : tab.catalogueCategory === "Kitchen"
                  ? props.menuItems.filter((m) => catalogueById.get(m.productId)?.category === "Kitchen").length
                  : tab.catalogueCategory === "Home care"
                    ? props.menuItems.filter((m) => catalogueById.get(m.productId)?.category === "Home care").length
                    : 0
            const activeTab = tab.id === active
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setActive(tab.id)
                  props.onSearchChange("")
                }}
                className={cn(
                  "category-tab snap-start shrink-0 flex flex-col items-center gap-1.5 min-w-[4.5rem] rounded-xl border px-2 py-2 transition-colors",
                  activeTab
                    ? "border-[var(--essenvia-teal)] bg-[var(--essenvia-teal)]/10 ring-2 ring-[var(--essenvia-teal)]/25"
                    : "border-transparent bg-white hover:border-[var(--essenvia-sage)]",
                )}
              >
                <div className="relative h-11 w-11 rounded-full overflow-hidden ring-1 ring-black/5">
                  <Image
                    src={categoryTabPhotos[tab.id]}
                    alt=""
                    fill
                    className="object-cover scale-110"
                    sizes="44px"
                  />
                </div>
                <span className="text-xs font-semibold text-center leading-tight">{tab.shortLabel}</span>
                {count > 0 && (
                  <span className="text-[10px] font-bold text-[var(--orange-dark)]">{count} picked</span>
                )}
              </button>
            )
          })}
        </div>
      </nav>

      <div className="menu-board-layout">
        <div className="menu-board-main space-y-5 min-w-0">
          <div className="rounded-2xl border bg-gradient-to-br from-white to-[var(--cream)] p-4 sm:p-5 space-y-4">
            <div>
              <h3 className="text-lg font-semibold">{config.label}</h3>
              <p className="text-sm text-muted-foreground mt-1">{config.blurb}</p>
            </div>

            {active === "laundry" && (
              <div className="space-y-4">
                <div>
                  <Label className="mb-2 block">Weekly laundry loads</Label>
                  <OptionGrid
                    options={laundryLoadOptions}
                    value={props.laundryLoads}
                    onChange={props.onLaundryLoads}
                    columns={2}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Detergent format</Label>
                  <OptionGrid
                    options={formatOptions}
                    value={props.detergentFormat}
                    onChange={props.onDetergentFormat}
                    columns={3}
                  />
                </div>
                <div>
                  <Label className="mb-2 block">Brand preference</Label>
                  <div className="flex flex-wrap gap-2">
                    {brandOptions.map((b) => (
                      <button
                        key={b}
                        type="button"
                        className={buttonVariants({
                          size: "sm",
                          variant: props.laundryBrand === b ? "default" : "outline",
                        })}
                        onClick={() => props.onLaundryBrand(b)}
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {active === "kitchen" && (
              <div>
                <Label className="mb-2 block">Dishwasher loads per week</Label>
                <OptionGrid
                  options={kitchenLoadOptions}
                  value={props.dishwasherLoads}
                  onChange={props.onDishwasherLoads}
                />
              </div>
            )}

            {(active === "paper-goods" || active === "cleaning" || active === "extras") && (
              <div>
                <Label className="mb-2 block">How fast do they go through these items?</Label>
                <OptionGrid
                  options={paceOptions}
                  value={props.restockPace}
                  onChange={props.onRestockPace}
                  columns={3}
                />
              </div>
            )}

            {topicsForTab.map((topic) => {
              if (!topic) return null
              const row = props.categoryInterests.find((c) => c.categoryId === topic.id)
              return (
                <div key={topic.id} className="space-y-2 pt-2 border-t border-[var(--sand)]">
                  <Label>How much does this home use — {topic.label.toLowerCase()}?</Label>
                  <p className="text-xs text-muted-foreground">{topic.examples}</p>
                  <div className="flex flex-wrap gap-2">
                    {frequencyOptions.map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        className={buttonVariants({
                          size: "sm",
                          variant: row?.importance === opt ? "default" : "outline",
                        })}
                        onClick={() => props.onCategoryImportance(topic.id, opt)}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>

          {active === "laundry" && (
            <details className="rounded-xl border bg-white px-4 py-3">
              <summary className="cursor-pointer font-medium text-sm">How Essenvia works</summary>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                {essenviaHowItWorks.points.map((point) => (
                  <li key={point.title}>
                    <strong className="text-foreground">{point.title}.</strong> {point.body}
                  </li>
                ))}
              </ul>
            </details>
          )}

          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9 survey-field-input"
              placeholder={`Search ${config.label.toLowerCase()}…`}
              value={props.search}
              onChange={(e) => props.onSearchChange(e.target.value)}
            />
          </div>

          {filteredProducts.length > 0 && (
            <section>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">Products</h4>
                <Badge variant="secondary">{filteredProducts.length} sizes</Badge>
              </div>
              <div className="ecom-product-grid">
                {filteredProducts.map((product) => (
                  <ProductEcomCard
                    key={product.id}
                    product={product}
                    quantity={qtyMap.get(product.id) ?? 0}
                    onAdd={() => props.onAdd(product.id)}
                    onAdjust={(d) => props.onAdjustQty(product.id, d)}
                  />
                ))}
              </div>
            </section>
          )}

          {showcases.length > 0 && (
            <section>
              <h4 className="font-semibold mb-3">Also discuss for the box</h4>
              <div className="ecom-product-grid">
                {showcases.map((item) => {
                  const line = props.menuItems.find((m) => m.custom?.notes === `pending:${item.id}`)
                  const qty = line?.quantity ?? 0
                  return (
                    <ShowcaseEcomCard
                      key={item.id}
                      title={item.name}
                      detail={item.detail}
                      image={item.image}
                      quantity={qty}
                      onAdd={() =>
                        props.onAddShowcase({
                          category: config.label,
                          productName: item.name,
                          sizeOrVariant: "Size TBD — capture on visit",
                          notes: `pending:${item.id}`,
                        })
                      }
                      onAdjust={(d) => {
                        if (line) props.onAdjustQty(line.productId, d)
                      }}
                    />
                  )
                })}
              </div>
            </section>
          )}
        </div>

        <aside className="menu-board-basket" aria-label="Customer box">
          <div className="sticky top-20 rounded-2xl border bg-white shadow-sm overflow-hidden">
            <div className="bg-[var(--essenvia-teal)] text-white px-4 py-3 flex items-center gap-2">
              <ShoppingBasket className="h-5 w-5" />
              <div className="flex-1">
                <p className="font-semibold">Your box</p>
                <p className="text-xs opacity-90">{props.boxLabel}</p>
              </div>
              <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-sm font-bold tabular-nums">
                {basketCount}
              </span>
            </div>
            <div className="max-h-[min(420px,50vh)] overflow-y-auto px-3">
              {props.menuItems.length === 0 ? (
                <p className="py-8 text-center text-sm text-muted-foreground px-2">
                  Nothing in the box yet — browse categories above and tap Add to box.
                </p>
              ) : (
                <ul>
                  {props.menuItems.map((line) => (
                    <BasketLine
                      key={line.productId}
                      line={line}
                      onAdjust={(d) => props.onAdjustQty(line.productId, d)}
                    />
                  ))}
                </ul>
              )}
            </div>
          </div>
        </aside>
      </div>
    </div>
  )
}
