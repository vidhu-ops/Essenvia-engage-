import { catalogue } from "@/data/catalogue"
import { productsInCategory, type CatalogueMenuCategory } from "@/data/catalogue-groups"
import {
  categoryImportanceOptions,
  surveyCategoryTopics,
  type SurveyCategoryTopicId,
} from "@/data/survey-categories"
import { showcaseLines } from "@/data/product-photos"

export type ShopCategoryId =
  | "laundry"
  | "kitchen"
  | "cleaning"
  | "paper-goods"
  | "personal-care"
  | "bathroom"
  | "extras"

export type ShopCategoryConfig = {
  id: ShopCategoryId
  label: string
  shortLabel: string
  blurb: string
  /** Links to surveyCategoryTopics for frequency capture */
  topicIds: SurveyCategoryTopicId[]
  catalogueCategory?: CatalogueMenuCategory
  showcaseIds?: string[]
}

export const shopCategories: ShopCategoryConfig[] = [
  {
    id: "laundry",
    label: "Laundry",
    shortLabel: "Laundry",
    blurb: "Loads per week, format, and every verified detergent & softener SKU.",
    topicIds: [],
    catalogueCategory: "Laundry",
  },
  {
    id: "kitchen",
    label: "Kitchen",
    shortLabel: "Kitchen",
    blurb: "Dishwasher habits plus Cascade and Palmolive pack sizes.",
    topicIds: ["kitchen-extras"],
    catalogueCategory: "Kitchen",
  },
  {
    id: "cleaning",
    label: "Cleaning",
    shortLabel: "Cleaning",
    blurb: "Bags, sprays, and wipes from the catalogue.",
    topicIds: ["bathroom-cleaning", "home-essentials"],
    catalogueCategory: "Home care",
  },
  {
    id: "paper-goods",
    label: "Paper goods",
    shortLabel: "Paper",
    blurb: "Toilet paper, towels, tissues — how often they restock.",
    topicIds: ["paper-goods"],
    showcaseIds: ["pending-toilet-paper", "pending-paper-towels"],
  },
  {
    id: "personal-care",
    label: "Personal care",
    shortLabel: "Personal",
    blurb: "Soap, toothpaste, and everyday care items.",
    topicIds: ["personal-care"],
    showcaseIds: ["pending-toothpaste"],
  },
  {
    id: "bathroom",
    label: "Bathroom",
    shortLabel: "Bath",
    blurb: "Bathroom cleaners and bowl care.",
    topicIds: ["bathroom-cleaning"],
    showcaseIds: ["pending-toilet-cleaner"],
  },
  {
    id: "extras",
    label: "Trash & more",
    shortLabel: "More",
    blurb: "Liners, batteries, and other home essentials.",
    topicIds: ["trash-liners"],
    showcaseIds: ["pending-black-bags-essential"],
  },
]

export function productsForShopCategory(id: ShopCategoryId) {
  const config = shopCategories.find((c) => c.id === id)!
  if (config.catalogueCategory) {
    return productsInCategory(config.catalogueCategory)
  }
  return []
}

export function showcasesForShopCategory(id: ShopCategoryId) {
  const config = shopCategories.find((c) => c.id === id)!
  if (!config.showcaseIds?.length) return []
  return showcaseLines.filter((s) => config.showcaseIds!.includes(s.id))
}

export const frequencyOptions = categoryImportanceOptions

export function topicMeta(topicId: SurveyCategoryTopicId) {
  return surveyCategoryTopics.find((t) => t.id === topicId)
}

export function allCatalogueProducts() {
  return catalogue
}
