import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Clock, Truck, Box } from "lucide-react"
import { WaveDivider } from "./wave-divider"
import { BoxCalculatorTable } from "@/components/box-calculator-table"
import {
  boxPlans,
  catalogue,
  CATALOGUE_SKU_COUNT,
  homePhotos,
  pendingProducts,
} from "@/data/catalogue"

const heroVideo =
  "https://videos.pexels.com/video-files/4100293/4100293-uhd_2560_1440_25fps.mp4"

export function EssenviaLandingPage() {
  return (
    <>
      <div className="announcement">
        <span>Delivery included across Canada on every Essenvia box</span>
        <span>Prices in CAD · {CATALOGUE_SKU_COUNT} catalogue SKUs</span>
      </div>

      <header className="site-header sticky top-0 z-40">
        <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between gap-4">
          <Link href="/" className="linked-logo">
            essenvia<span>+</span>
          </Link>
          <nav className="nav-links">
            <a href="#how">How it works</a>
            <a href="#inside-box">What&apos;s in the box</a>
            <a href="#save">Save money</a>
            <a href="#products">Products</a>
          </nav>
          <Link href="/survey" className="button primary">
            Start survey <ArrowRight size={16} />
          </Link>
        </div>
      </header>

      <section className="hero-split">
        <div className="hero-copy-block">
          <p className="kicker">Canadian-owned household care</p>
          <h1>
            Home essentials, without the <em>mental load.</em>
          </h1>
          <p>
            Tell us what your household uses. We build a personalized box of trusted
            brands, show exactly what goes inside, and deliver before you run out.
          </p>
          <div className="hero-actions">
            <Link href="/survey" className="button primary">
              Build a box with customer <ArrowRight size={16} />
            </Link>
            <a href="#inside-box" className="button outline">
              See box contents
            </a>
          </div>
          <div className="hero-proof">
            <span className="inline-flex items-center gap-1">
              <Clock size={15} /> About 5 minutes
            </span>
            <span className="inline-flex items-center gap-1">
              <Truck size={15} /> Delivery included
            </span>
            <span className="inline-flex items-center gap-1">
              <Box size={15} /> Clear CAD pricing
            </span>
          </div>
        </div>
        <div className="hero-media">
          <video autoPlay loop muted playsInline poster={homePhotos.kitchen}>
            <source src={heroVideo} type="video/mp4" />
          </video>
          <div className="hero-media-shade" />
        </div>
      </section>

      <WaveDivider />
      <div className="brand-strip">YOUR FAVOURITES, ALL IN ONE BOX · TIDE · GAIN · CASCADE · GLAD · LYSOL · CLOROX</div>

      <section className="visual-story" id="about">
        <div>
          <p className="kicker">Made for the everyday</p>
          <h2>A little more room for life.</h2>
          <p style={{ color: "var(--ink-muted)", lineHeight: 1.75 }}>
            Fresh towels. A clear counter. The comfort of knowing the basics are already
            covered — with the brands your customer already trusts.
          </p>
          <Link href="/survey" className="button outline" style={{ marginTop: "1rem" }}>
            Run the household survey
          </Link>
        </div>
        <figure style={{ margin: 0 }}>
          <Image
            src={homePhotos.laundry}
            alt="Bright laundry space"
            width={700}
            height={850}
            className="round-tall"
          />
          <figcaption style={{ fontSize: "0.65rem", color: "var(--ink-muted)", marginTop: 8 }}>
            Laundry day, simplified.
          </figcaption>
        </figure>
        <figure style={{ margin: 0, alignSelf: "end" }}>
          <Image
            src={homePhotos.kitchen}
            alt="Sunlit kitchen"
            width={500}
            height={400}
            className="round-mid"
          />
        </figure>
      </section>

      <WaveDivider flip />
      <section className="section cream" id="how">
        <p className="kicker">How it works</p>
        <h2>One less list to keep in your head.</h2>
        <p style={{ color: "var(--ink-muted)", maxWidth: "40rem", lineHeight: 1.7 }}>
          Essenvia learns household rhythm and packages repeat shopping into one delivery.
          Sales teams capture preferences in a guided survey — no payment required on the call.
        </p>
        <div className="steps-grid" style={{ marginTop: "2rem" }}>
          {[
            ["01", "Loads & household", "Laundry and dishwasher loads first, then household size for the box."],
            ["02", "Box calculator", "Compare Essential, Standard, and Premium with line-by-line contents."],
            [
              "03",
              "Category menus",
              `Laundry, kitchen, and home care — every ${CATALOGUE_SKU_COUNT} SKU with its own image and specifications.`,
            ],
          ].map(([num, title, copy]) => (
            <article key={num} className="step-card">
              <span className="num">{num}</span>
              <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "1.25rem" }}>{title}</h3>
              <p style={{ color: "var(--ink-muted)", fontSize: "0.9rem", lineHeight: 1.6 }}>{copy}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section" id="inside-box">
        <p className="kicker">The details matter</p>
        <h2>Know what goes into the box.</h2>
        <p style={{ color: "var(--ink-muted)", marginBottom: "1.5rem" }}>
          One detergent choice per box. Physical roll counts. Draft assignments from the
          official catalogue —{" "}
          <a href="/Essenvia-product-catalogue.pdf" className="underline">
            view PDF
          </a>
          .
        </p>
        <BoxCalculatorTable selectedPlan="standard" />
      </section>

      <section className="section cream" id="save">
        <p className="kicker">Clear value</p>
        <h2>How households save with Essenvia.</h2>
        <div className="savings-grid" style={{ marginTop: "1.5rem" }}>
          {[
            ["$84.99–$104.99", "One transparent CAD price per box with delivery included."],
            ["Fewer trips", "Less emergency shopping and fewer half-used products at home."],
            ["Right-sized packs", "Quantities matched to household size — not bulk you don't need."],
          ].map(([head, copy]) => (
            <div key={head} className="savings-card">
              <strong>{head}</strong>
              <p style={{ color: "var(--ink-muted)", margin: 0, fontSize: "0.9rem" }}>{copy}</p>
            </div>
          ))}
        </div>
        <div className="steps-grid" style={{ marginTop: "2rem" }}>
          {boxPlans.map((plan) => (
            <article key={plan.id} className="step-card">
              <p className="kicker">{plan.label}</p>
              <h3 style={{ fontFamily: "var(--font-heading)" }}>{plan.retailName}</h3>
              <p style={{ fontSize: "1.5rem", fontWeight: 600 }}>${plan.priceCad.toFixed(2)} CAD</p>
              <p style={{ color: "var(--ink-muted)", fontSize: "0.85rem" }}>{plan.productRange}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section" id="products">
        <p className="kicker">Catalogue</p>
        <h2>{CATALOGUE_SKU_COUNT} verified products in the survey menu.</h2>
        <div
          style={{
            display: "grid",
            gap: "0.75rem",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            marginTop: "1.5rem",
          }}
        >
          {catalogue.slice(0, 8).map((p) => (
            <article
              key={p.id}
              style={{
                border: "1px solid var(--sand)",
                borderRadius: "1rem",
                padding: "1rem",
                background: "var(--cream)",
              }}
            >
              <p className="kicker">{p.category}</p>
              <h3 style={{ fontSize: "1rem", margin: "0.25rem 0" }}>
                {p.brand} {p.name}
              </h3>
              <p style={{ fontSize: "0.8rem", color: "var(--ink-muted)" }}>
                {p.variant} · {p.netQuantity}
              </p>
            </article>
          ))}
        </div>
        <p style={{ marginTop: "1rem", fontSize: "0.85rem", color: "var(--ink-muted)" }}>
          The field survey also captures paper goods, personal care, and other home essentials — plus
          custom product and size requests when we do not stock every variant ({pendingProducts.length}{" "}
          catalogue rows still pending supplier confirmation).
        </p>
        <Link href="/survey" className="button primary" style={{ marginTop: "1.25rem" }}>
          Open full product menu in survey
        </Link>
      </section>

      <section className="section cream">
        <figure style={{ margin: 0, maxWidth: 900, marginInline: "auto" }}>
          <Image
            src={homePhotos.laundryDetail}
            alt="Organized laundry room"
            width={900}
            height={600}
            style={{ width: "100%", height: "auto", borderRadius: "1.5rem" }}
          />
          <figcaption style={{ textAlign: "center", marginTop: 12, color: "var(--ink-muted)" }}>
            A little less to keep in mind.
          </figcaption>
        </figure>
      </section>

      <section className="section" style={{ textAlign: "center" }}>
        <h2>Ready for a customer conversation?</h2>
        <p style={{ color: "var(--ink-muted)", maxWidth: "32rem", margin: "0 auto 1.5rem" }}>
          Capture answers in Postgres-backed storage. Upload your talk track so you never miss a
          talking point.
        </p>
        <Link href="/survey" className="button primary">
          Start production survey
        </Link>
      </section>

      <footer>
        <p>© 2026 Essenvia Canada Inc. · Survey data stored securely on server · Prices in CAD</p>
      </footer>
    </>
  )
}
