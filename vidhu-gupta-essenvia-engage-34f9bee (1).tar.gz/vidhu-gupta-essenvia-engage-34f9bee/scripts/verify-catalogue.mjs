import { readFileSync } from "fs"
import { fileURLToPath } from "url"
import { dirname, join } from "path"
import { createRequire } from "module"

const require = createRequire(import.meta.url)
const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, "..")

// Dynamic import TS catalogue via compiled path — use JSON manifest instead
const manifestPath = join(root, "src/data/catalogue-manifest.json")
const manifest = JSON.parse(readFileSync(manifestPath, "utf-8"))

const tsSource = readFileSync(join(root, "src/data/catalogue.ts"), "utf-8")
const idMatches = [...tsSource.matchAll(/item\(\s*"([^"]+)"/g)].map((m) => m[1])
const uniqueIds = new Set(idMatches)

let failed = false

if (uniqueIds.size !== manifest.expectedSkuIds.length) {
  console.error(
    `SKU count mismatch: code has ${uniqueIds.size}, manifest expects ${manifest.expectedSkuIds.length}`,
  )
  failed = true
}

for (const id of manifest.expectedSkuIds) {
  if (!uniqueIds.has(id)) {
    console.error(`Missing SKU id in catalogue.ts: ${id}`)
    failed = true
  }
}

for (const id of uniqueIds) {
  if (!manifest.expectedSkuIds.includes(id)) {
    console.error(`Unexpected SKU id in catalogue.ts: ${id}`)
    failed = true
  }
}

if (failed) {
  process.exit(1)
}

console.log(
  `Catalogue OK: ${manifest.expectedSkuIds.length} SKUs match ${manifest.source}`,
)
