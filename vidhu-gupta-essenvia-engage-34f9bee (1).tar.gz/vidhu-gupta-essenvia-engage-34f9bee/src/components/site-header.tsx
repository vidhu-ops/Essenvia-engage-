import Link from "next/link"
import { buttonVariants } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function SiteHeader() {
  return (
    <>
      <div className="bg-[var(--essenvia-teal)] text-white text-center text-sm py-2 px-4 flex flex-wrap justify-center gap-x-6 gap-y-1">
        <span>Canadian-owned · Delivery included · Prices in CAD</span>
        <span className="opacity-90">Sales field survey tool</span>
      </div>
      <header className="sticky top-0 z-50 bg-[var(--essenvia-cream)]/95 backdrop-blur border-b border-[var(--essenvia-sage)]/30">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between gap-4">
          <Link href="/" className="text-2xl tracking-tight text-[var(--essenvia-forest)]">
            essenvia<span className="text-[var(--essenvia-maple)]">+</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[var(--essenvia-forest)]">
            <Link href="/#how" className="hover:text-[var(--essenvia-teal)]">
              How it works
            </Link>
            <Link href="/#products" className="hover:text-[var(--essenvia-teal)]">
              Products
            </Link>
            <Link href="/#box-calculator" className="hover:text-[var(--essenvia-teal)]">
              Box calculator
            </Link>
          </nav>
          <Link href="/survey" className={cn(buttonVariants(), "shrink-0")}>
            Start customer survey
          </Link>
        </div>
      </header>
    </>
  )
}
