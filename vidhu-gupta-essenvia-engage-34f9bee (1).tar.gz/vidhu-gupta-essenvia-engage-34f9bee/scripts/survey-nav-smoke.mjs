#!/usr/bin/env node
/** Clicks Continue through survey step 1 → 2 (requires dev/prod server on BASE_URL). */
import { chromium } from "playwright"

const base = process.env.BASE_URL ?? "http://127.0.0.1:4321"

async function expectSkuSpec(page) {
  await page.getByText("Pack size").first().waitFor({ timeout: 5000 })
  await page.getByText("Case pack").first().waitFor({ timeout: 5000 })
}

async function main() {
  const browser = await chromium.launch({ headless: true })
  const page = await browser.newPage()
  page.on("pageerror", (err) => console.error("pageerror:", err.message))
  await page.goto(`${base}/survey`, { waitUntil: "networkidle" })
  await page.getByText("Loading survey…").waitFor({ state: "hidden", timeout: 15000 }).catch(() => {})
  await page.getByRole("heading", { name: /Household & Essenvia plan/i }).waitFor({ timeout: 10000 })
  await page.getByTestId("survey-continue").click()
  await page.getByRole("heading", { name: /Shop by category/i }).waitFor({ timeout: 5000 })
  await page.getByTestId("category-shop").waitFor({ timeout: 5000 })
  console.log("✓ Category shop with product grid")
  await browser.close()
}

main().catch((e) => {
  console.error("✗", e.message)
  process.exit(1)
})
