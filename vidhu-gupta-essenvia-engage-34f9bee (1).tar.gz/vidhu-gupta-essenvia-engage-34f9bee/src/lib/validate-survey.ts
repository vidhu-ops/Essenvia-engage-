import { z } from "zod"
import { catalogueById } from "@/data/catalogue"

const boxPlanSchema = z.enum(["essential", "standard", "premium"])

export const surveySubmitSchema = z.object({
  household: z.object({
    size: z.string().min(1),
    laundryLoads: z.string().min(1),
    detergentFormat: z.string().min(1),
    laundryBrand: z.string().min(1),
    dishwasherLoads: z.string().min(1),
    restockPace: z.string().min(1),
  }),
  boxPlan: boxPlanSchema,
  menuItems: z
    .array(
      z.object({
        productId: z.string().min(1),
        quantity: z.number().int().min(1).max(99),
        custom: z
          .object({
            category: z.string().trim().min(1).max(80),
            productName: z.string().trim().min(1).max(200),
            brand: z.string().trim().max(120).optional(),
            sizeOrVariant: z.string().trim().min(1).max(200),
            notes: z.string().trim().max(1000).optional(),
          })
          .optional(),
      }),
    )
    .default([]),
  categoryInterests: z
    .array(
      z.object({
        categoryId: z.string().min(1),
        importance: z.string().min(1),
        currentProducts: z.string().trim().max(500).optional(),
        preferredItems: z.string().trim().max(1000).optional(),
        notes: z.string().trim().max(2000).optional(),
      }),
    )
    .default([]),
  productAnswers: z
    .array(
      z.object({
        productId: z.string().min(1),
        usage: z.string().optional(),
        satisfaction: z.string().optional(),
        priority: z.string().optional(),
        notes: z.string().max(2000).optional(),
      }),
    )
    .default([]),
  customerNotes: z.string().max(5000).optional(),
  talkTrack: z
    .object({
      scriptText: z.string().max(50000).optional(),
      scriptFilename: z.string().max(255).optional(),
      repNotes: z.string().max(5000).optional(),
    })
    .optional(),
  salesRep: z.object({
    name: z.string().trim().min(2).max(120),
    code: z.string().trim().min(2).max(64),
  }),
})

export type SurveySubmitInput = z.infer<typeof surveySubmitSchema>

function isCustomMenuLine(productId: string, custom: SurveySubmitInput["menuItems"][number]["custom"]) {
  return productId.startsWith("custom-") && !!custom?.productName
}

export function assertCatalogueProducts(input: SurveySubmitInput): string[] {
  const errors: string[] = []
  const menuIds = new Set(input.menuItems.map((m) => m.productId))
  for (const line of input.menuItems) {
    if (catalogueById.has(line.productId)) {
      if (line.custom) {
        errors.push(`Catalogue SKU should not include custom details: ${line.productId}`)
      }
      continue
    }
    if (!isCustomMenuLine(line.productId, line.custom)) {
      errors.push(`Unknown product in menu: ${line.productId}`)
    }
  }
  for (const answer of input.productAnswers) {
    const inCatalogue = catalogueById.has(answer.productId)
    const menuLine = input.menuItems.find((m) => m.productId === answer.productId)
    const isCustom = menuLine && isCustomMenuLine(answer.productId, menuLine.custom)
    if (!inCatalogue && !isCustom) {
      errors.push(`Unknown product in answers: ${answer.productId}`)
    }
    if (!menuIds.has(answer.productId)) {
      errors.push(`Answer without menu line: ${answer.productId}`)
    }
  }
  return errors
}
