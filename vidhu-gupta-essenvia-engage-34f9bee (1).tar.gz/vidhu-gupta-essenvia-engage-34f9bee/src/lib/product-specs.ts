import type { CatalogueProduct } from "@/data/catalogue"

export type ProductSpecRow = { label: string; value: string }

export function getProductSpecRows(product: CatalogueProduct): ProductSpecRow[] {
  return [
    { label: "Catalogue SKU", value: product.id },
    { label: "Brand", value: product.brand },
    { label: "Product line", value: product.name },
    { label: "Variant / scent", value: product.variant },
    { label: "Pack size", value: product.netQuantity },
    { label: "Form", value: product.form },
    { label: "Packaging", value: product.packaging },
    { label: "Case pack", value: `${product.casePack} units per case` },
    { label: "Category", value: product.category },
  ]
}

export function catalogueSearchBlob(product: CatalogueProduct): string {
  return `${product.brand} ${product.name} ${product.variant} ${product.netQuantity} ${product.form} ${product.id}`.toLowerCase()
}
