import { EssenviaLandingPage } from "@/components/essenvia/landing-page"

export default function HomePage() {
  return (
    <div className="site-theme theme-1">
      <EssenviaLandingPage />
    </div>
  )
}
