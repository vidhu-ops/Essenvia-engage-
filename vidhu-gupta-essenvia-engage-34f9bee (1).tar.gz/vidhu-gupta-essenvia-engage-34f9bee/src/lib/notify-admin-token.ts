const DEFAULT_TO = "careers@essenvia.ca"

export async function notifyAdminTokenProvisioned(token: string): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY?.trim()
  if (!apiKey) return false

  const from =
    process.env.RESEND_FROM?.trim() || "Essenvia Surveys <onboarding@resend.dev>"
  const to = process.env.SURVEY_NOTIFY_TO?.trim() || DEFAULT_TO
  const subject = "Essenvia survey admin API token (save securely)"

  const text = [
    "A bearer token was created for listing submitted surveys via the API.",
    "",
    "GET /api/surveys",
    `Authorization: Bearer ${token}`,
    "",
    "You can override this token anytime by setting SURVEYS_ADMIN_TOKEN in environment variables.",
    "This email is sent once when the token is first provisioned in the database.",
  ].join("\n")

  const html = `
    <p>A bearer token was created for listing submitted surveys via the API.</p>
    <p><strong>GET</strong> <code>/api/surveys</code><br/>
    Header: <code>Authorization: Bearer ${token}</code></p>
    <p>Override anytime with the <code>SURVEYS_ADMIN_TOKEN</code> environment variable.</p>
  `

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from, to: [to], subject, text, html }),
  })
  return res.ok
}
