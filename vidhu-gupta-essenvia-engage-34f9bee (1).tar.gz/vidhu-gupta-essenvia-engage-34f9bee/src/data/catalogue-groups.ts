import { catalogue, type CatalogueProduct } from "@/data/catalogue"

export const catalogueMenuCategories = ["Laundry", "Kitchen", "Home care"] as const

export type CatalogueMenuCategory = (typeof catalogueMenuCategories)[number]

export function productsInCategory(category: CatalogueMenuCategory): CatalogueProduct[] {
  return catalogue.filter((p) => p.category === category)
}

export function countInCategory(category: CatalogueMenuCategory): number {
  return productsInCategory(category).length
}
