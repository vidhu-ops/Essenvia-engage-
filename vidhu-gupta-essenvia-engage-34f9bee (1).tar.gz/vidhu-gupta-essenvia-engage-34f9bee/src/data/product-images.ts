import type { CatalogueProduct } from "@/data/catalogue"
import { homePhotos } from "@/data/catalogue"
const formToPack: Record<string, string> = {
  Pods: "/images/products/pods.svg",
  ActionPacs: "/images/products/dish.svg",
  Liquid: "/images/products/liquid.svg",
  "Premoistened wipes": "/images/products/wipes.svg",
  "Plastic bags": "/images/products/bags.svg",
  "Liquid spray": "/images/products/liquid.svg",
}

const categoryPhoto: Record<CatalogueProduct["category"], string> = {
  Laundry: homePhotos.laundryDetail,
  Kitchen: homePhotos.kitchen,
  "Home care": homePhotos.sink,
}

export function getProductPackImage(product: CatalogueProduct): string {
  return `/images/products/skus/${product.id}.svg`
}

export function getProductPackImageFallback(product: CatalogueProduct): string {
  return formToPack[product.form] ?? "/images/products/liquid.svg"
}

/** Lifestyle photo for category headers and custom lines. */
export function getCategoryPhoto(category: string): string {
  if (category === "Laundry") return categoryPhoto.Laundry
  if (category === "Kitchen") return categoryPhoto.Kitchen
  if (category === "Home care") return categoryPhoto["Home care"]
  if (category === "Paper goods") return homePhotos.sink
  return homePhotos.laundry
}

export const CUSTOM_LINE_IMAGE = "/images/products/custom.svg"
