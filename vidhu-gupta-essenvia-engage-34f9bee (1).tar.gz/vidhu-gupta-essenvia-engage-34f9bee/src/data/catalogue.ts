// Source: Essenvia Product Catalogue (PDF handoff, no prices) — verified SKU list.
export type CatalogueProduct = {
  id: string
  brand: string
  name: string
  variant: string
  category: "Laundry" | "Kitchen" | "Home care"
  form: string
  netQuantity: string
  casePack: number
  packaging: string
}

export const CATALOGUE_SOURCE =
  "Essenvia_Product_Catalogue_No_Prices_5f09.pdf (developer handoff)"

/** Expected active SKU count from PDF pages 1–2 (distinct size/scent/case rows). */
export const CATALOGUE_SKU_COUNT = 26

const item = (
  id: string,
  brand: string,
  name: string,
  variant: string,
  category: CatalogueProduct["category"],
  form: string,
  netQuantity: string,
  casePack: number,
  packaging = "Retail pack*",
): CatalogueProduct => ({
  id,
  brand,
  name,
  variant,
  category,
  form,
  netQuantity,
  casePack,
  packaging,
})

export const catalogue: CatalogueProduct[] = [
  item("tide-free-16", "Tide", "PODS Free & Gentle", "Free & Gentle", "Laundry", "Pods", "16 pods", 24),
  item("tide-free-35", "Tide", "PODS Free & Gentle", "Free & Gentle", "Laundry", "Pods", "35 pods", 10),
  item("tide-oxi-15", "Tide", "PODS Ultra Oxi", "Ultra Oxi", "Laundry", "Pods", "15 pods", 24),
  item("tide-downy-32", "Tide", "PODS Downy 4-in-1", "Downy variant", "Laundry", "Pods", "32 pods", 10),
  item("tide-liquid-109", "Tide", "Liquid Odour Oxi", "26 advertised loads", "Laundry", "Liquid", "1.09 L", 6, "Bottle"),
  item("tide-liquid-215", "Tide", "Liquid Odour Oxi", "52 advertised loads", "Laundry", "Liquid", "2.15 L", 4, "Bottle"),
  item("tide-zero-310", "Tide", "Zero Soft Citrus", "80 advertised loads", "Laundry", "Liquid", "3.10 L", 4, "Bottle"),
  item("gain-31", "Gain", "Flings 3-in-1", "Original scent", "Laundry", "Pods", "31 pods", 10),
  item("gain-38", "Gain", "Flings 3-in-1", "Original scent", "Laundry", "Pods", "38 pods", 6),
  item("downy-166", "Downy", "Gentle Soft", "Orange Blossom; 83 advertised loads", "Laundry", "Liquid", "1.66 L", 4, "Bottle"),
  item("cascade-fresh-14", "Cascade", "Platinum", "Fresh scent", "Kitchen", "ActionPacs", "14 pods", 14),
  item("cascade-lemon-21", "Cascade", "Free & Clear", "Lemon", "Kitchen", "ActionPacs", "21 pods", 5),
  item("cascade-fresh-21-case12", "Cascade", "Platinum", "Fresh scent · supplier listing A", "Kitchen", "ActionPacs", "21 pods", 12),
  item("cascade-fresh-21-case16", "Cascade", "Platinum", "Fresh scent · supplier listing B", "Kitchen", "ActionPacs", "21 pods", 16),
  item("palmolive-original-372", "Palmolive", "Essential Clean", "Original", "Kitchen", "Liquid", "372 mL", 20, "Bottle"),
  item("palmolive-orange-372", "Palmolive", "Essential Clean", "Orange Tangerine", "Kitchen", "Liquid", "372 mL", 20, "Bottle"),
  item("palmolive-ultra-591", "Palmolive", "Ultra Strength", "Original", "Kitchen", "Liquid", "591 mL", 9, "Bottle"),
  item("palmolive-lemon-828", "Palmolive", "Lemon Citrus", "Lemon Citrus", "Kitchen", "Liquid", "828 mL", 16, "Bottle"),
  item("glad-black-74", "Glad", "Regular Black", "74 L bag capacity", "Home care", "Plastic bags", "40 bags", 8),
  item("glad-black-90", "Glad", "Large Black", "90 L bag capacity", "Home care", "Plastic bags", "24 bags", 6),
  item("glad-white-45", "Glad", "Tall White", "45 L bag capacity", "Home care", "Plastic bags", "30 bags", 6),
  item("lysol-lemon-650", "Lysol", "All Purpose", "Lemon", "Home care", "Liquid spray", "650 mL", 12, "Trigger bottle"),
  item("clorox-fresh-35", "Clorox", "Disinfecting Wipes", "Fresh Scent", "Home care", "Premoistened wipes", "35 wipes", 12, "Container*"),
  item("clorox-lemon-35", "Clorox", "Disinfecting Wipes", "Lemon Fresh", "Home care", "Premoistened wipes", "35 wipes", 12, "Container*"),
  item("clorox-fresh-75", "Clorox", "Disinfecting Wipes", "Fresh Scent", "Home care", "Premoistened wipes", "75 wipes", 6, "Container*"),
  item("clorox-lemon-75", "Clorox", "Disinfecting Wipes", "Lemon Fresh", "Home care", "Premoistened wipes", "75 wipes", 6, "Container*"),
]

export const catalogueById = new Map(catalogue.map((p) => [p.id, p]))

export const pendingProducts = [
  {
    id: "pending-toilet-paper",
    name: "Cashmere toilet paper",
    detail: "Variant, ply, sheets per roll, retail pack, and case pack pending.",
  },
  {
    id: "pending-paper-towels",
    name: "SpongeTowels paper towels",
    detail: "Variant, sheets per roll, retail pack, and case pack pending.",
  },
  {
    id: "pending-toothpaste",
    name: "Toothpaste",
    detail: "Brand undecided; Crest considered. Formula, tube size, and case pack pending.",
  },
  {
    id: "pending-toilet-cleaner",
    name: "Lysol toilet bowl cleaner",
    detail: "Formula, bottle size, form, and case pack pending.",
  },
  {
    id: "pending-black-bags-essential",
    name: "Smaller black garbage bags (Essential box)",
    detail: "Brand, capacity, and smaller factory-sealed pack pending.",
  },
] as const

export const boxRows: string[][] = [
  ["Toilet paper", "18 physical rolls", "24 physical rolls", "30 physical rolls"],
  ["Paper towels", "4 physical rolls", "6 physical rolls", "8 physical rolls"],
  ["Laundry detergent · one choice", "1 smaller pack / bottle", "1 larger pack / bottle", "1 larger pack / bottle"],
  ["Downy softener · 1.66 L", "1 bottle", "1 bottle", "2 bottles"],
  ["Cascade", "1 × 14-count", "1 × 21-count", "1 × 21-count"],
  ["Palmolive", "1 × 372 mL", "1 × 591 mL", "2 × 591 mL"],
  ["Black garbage bags", "Pending smaller pack", "1 × 40-count, 74 L", "1 × 40-count, 74 L"],
  ["White kitchen bags", "1 × 30-count, 45 L", "1 × 30-count, 45 L", "1 × 30-count, 45 L"],
  ["Lysol all-purpose · 650 mL", "1 bottle", "1 bottle", "2 bottles"],
  ["Clorox wipes", "1 × 35-count", "1 × 75-count", "2 × 75-count"],
  ["Toothpaste", "1 tube proposed; size pending", "1 tube proposed; size pending", "1 tube proposed; size pending"],
  ["Lysol toilet bowl cleaner", "1 bottle proposed; size pending", "1 bottle proposed; size pending", "1 bottle proposed; size pending"],
]

export type BoxPlanId = "essential" | "standard" | "premium"

export const boxPlans = [
  {
    id: "essential" as const,
    label: "Essential",
    retailName: "Essenvia Essential",
    priceCad: 84.99,
    productRange: "8–12 essentials",
    columnIndex: 1 as const,
  },
  {
    id: "standard" as const,
    label: "Standard",
    retailName: "Essenvia Family",
    priceCad: 94.99,
    productRange: "12–16 essentials",
    columnIndex: 2 as const,
  },
  {
    id: "premium" as const,
    label: "Premium",
    retailName: "Essenvia Plus",
    priceCad: 104.99,
    productRange: "16–20 essentials",
    columnIndex: 3 as const,
  },
]

export function recommendPlan(household: string): BoxPlanId {
  if (household === "5+ people") return "premium"
  if (["Just me", "2 people"].includes(household)) return "essential"
  return "standard"
}

export const productSurveyQuestions = [
  {
    id: "usage",
    label: "How often does the household use this?",
    options: ["Daily", "Several times a week", "Weekly", "Occasionally", "Rarely / not sure"],
  },
  {
    id: "satisfaction",
    label: "How happy are they with their current choice?",
    options: ["Very happy", "Mostly fine", "Would switch", "Not currently using"],
  },
  {
    id: "priority",
    label: "Should this be in the first box?",
    options: ["Must have", "Nice to have", "Only if budget allows", "Skip for now"],
  },
] as const

export const homePhotos = {
  laundry: "/images/laundry.jpg",
  kitchen: "/images/kitchen.jpg",
  sink: "/images/sink.jpg",
  laundryDetail: "/images/laundry-detail.jpg",
}
