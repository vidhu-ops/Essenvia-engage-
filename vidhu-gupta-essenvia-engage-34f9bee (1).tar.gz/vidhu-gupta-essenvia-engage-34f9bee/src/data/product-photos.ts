import type { CatalogueProduct } from "@/data/catalogue"
import { homePhotos, pendingProducts } from "@/data/catalogue"

/** Per-SKU pack art (brand, size, form) — committed under public/images/products/skus/. */
export function skuPackImage(skuId: string): string {
  return `/images/products/skus/${skuId}.svg`
}

export function getCatalogueProductPhoto(product: CatalogueProduct): string {
  return skuPackImage(product.id)
}

const categoryIllustrations: Record<string, string> = {
  laundry: homePhotos.laundryDetail,
  kitchen: homePhotos.kitchen,
  cleaning: homePhotos.sink,
  "paper-goods": "/images/products/pods.svg",
  "personal-care": "/images/products/custom.svg",
  bathroom: homePhotos.sink,
  extras: "/images/products/bags.svg",
}

export const categoryTabPhotos: Record<string, string> = categoryIllustrations

const pendingIllustration: Record<string, string> = {
  "pending-toilet-paper": "/images/products/pods.svg",
  "pending-paper-towels": "/images/products/wipes.svg",
  "pending-toothpaste": "/images/products/custom.svg",
  "pending-toilet-cleaner": "/images/products/liquid.svg",
  "pending-black-bags-essential": "/images/products/bags.svg",
}

export const showcaseLines = pendingProducts.map((p) => ({
  ...p,
  image: pendingIllustration[p.id] ?? "/images/products/custom.svg",
}))
