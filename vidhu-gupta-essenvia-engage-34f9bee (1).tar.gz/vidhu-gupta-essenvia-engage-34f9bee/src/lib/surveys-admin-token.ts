import { randomBytes } from "crypto"
import { ensureSchema, getSql, getStorageBackend } from "@/lib/db"
import { notifyAdminTokenProvisioned } from "@/lib/notify-admin-token"

const SETTING_KEY = "surveys_admin_token"
const EMAILED_KEY = "surveys_admin_token_emailed"

function tokenFromEnv(): string | undefined {
  const v = process.env.SURVEYS_ADMIN_TOKEN?.trim()
  return v || undefined
}

function newAdminToken(): string {
  return `ev_adm_${randomBytes(24).toString("base64url")}`
}

/** Resolves the bearer token for GET /api/surveys. Env wins; otherwise Postgres (auto-created once). */
export async function resolveSurveyAdminToken(): Promise<string | null> {
  const fromEnv = tokenFromEnv()
  if (fromEnv) return fromEnv

  if (getStorageBackend() === "unconfigured") {
    return null
  }

  await ensureSchema()
  const sql = getSql()

  const existing = await sql<{ value: string }[]>`
    SELECT value FROM app_settings WHERE key = ${SETTING_KEY} LIMIT 1
  `
  if (existing[0]?.value) {
    return existing[0].value
  }

  const token = newAdminToken()
  await sql`
    INSERT INTO app_settings (key, value, created_at)
    VALUES (${SETTING_KEY}, ${token}, NOW())
    ON CONFLICT (key) DO NOTHING
  `

  const row = await sql<{ value: string }[]>`
    SELECT value FROM app_settings WHERE key = ${SETTING_KEY} LIMIT 1
  `
  const resolved = row[0]?.value ?? token

  const emailed = await sql<{ value: string }[]>`
    SELECT value FROM app_settings WHERE key = ${EMAILED_KEY} LIMIT 1
  `
  if (!emailed[0]?.value) {
    const sent = await notifyAdminTokenProvisioned(resolved)
    if (sent) {
      await sql`
        INSERT INTO app_settings (key, value, created_at)
        VALUES (${EMAILED_KEY}, ${"1"}, NOW())
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value
      `
    }
  }

  return resolved
}
