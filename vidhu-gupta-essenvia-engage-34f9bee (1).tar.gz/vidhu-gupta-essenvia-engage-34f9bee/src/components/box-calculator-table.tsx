"use client"

import { boxPlans, boxRows, type BoxPlanId } from "@/data/catalogue"
import { cn } from "@/lib/utils"

type Props = {
  selectedPlan: BoxPlanId
  onSelectPlan?: (plan: BoxPlanId) => void
  interactive?: boolean
}

export function BoxCalculatorTable({
  selectedPlan,
  onSelectPlan,
  interactive = false,
}: Props) {
  return (
    <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
      <table className="w-full min-w-[640px] text-sm">
        <caption className="sr-only">
          Proposed box contents by Essential, Standard, and Premium plans
        </caption>
        <thead>
          <tr className="border-b bg-[var(--essenvia-cream)]">
            <th scope="col" className="p-3 text-left font-semibold">
              Everyday category
            </th>
            {boxPlans.map((plan) => (
              <th
                key={plan.id}
                scope="col"
                className={cn(
                  "p-3 text-left font-semibold",
                  selectedPlan === plan.id && "bg-[var(--essenvia-teal)]/15",
                )}
              >
                {interactive ? (
                  <button
                    type="button"
                    onClick={() => onSelectPlan?.(plan.id)}
                    className={cn(
                      "text-left w-full rounded-lg p-1 -m-1 transition-colors",
                      selectedPlan === plan.id &&
                        "ring-2 ring-[var(--essenvia-teal)]",
                    )}
                  >
                    <span className="block">{plan.label}</span>
                    <span className="block text-xs font-normal text-muted-foreground">
                      ${plan.priceCad.toFixed(2)} CAD
                    </span>
                  </button>
                ) : (
                  <>
                    <span className="block">{plan.label}</span>
                    <span className="block text-xs font-normal text-muted-foreground">
                      ${plan.priceCad.toFixed(2)} CAD
                    </span>
                  </>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {boxRows.map(([label, essential, standard, premium]) => {
            const values = [essential, standard, premium] as const
            return (
              <tr key={label} className="border-b last:border-0">
                <th scope="row" className="p-3 text-left font-medium">
                  {label}
                </th>
                {boxPlans.map((plan, i) => (
                  <td
                    key={plan.id}
                    className={cn(
                      "p-3 text-muted-foreground",
                      selectedPlan === plan.id && "bg-[var(--essenvia-teal)]/8 font-medium text-foreground",
                    )}
                  >
                    {values[i]}
                  </td>
                ))}
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
