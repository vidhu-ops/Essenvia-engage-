import { catalogueById } from "@/data/catalogue"
import type { SurveyPayload } from "@/types/survey"

const DEFAULT_TO = "careers@essenvia.ca"

export type NotifyResult =
  | { sent: true; provider: "resend"; messageId?: string }
  | { sent: false; reason: string }

function notifyTo(): string {
  return process.env.SURVEY_NOTIFY_TO?.trim() || DEFAULT_TO
}

function formatSurveyEmail(payload: SurveyPayload): { subject: string; text: string; html: string } {
  const menuLines = payload.menuItems
    .map((line) => {
      const p = catalogueById.get(line.productId)
      const label = p
        ? `${line.quantity}× ${p.brand} ${p.name} (${p.netQuantity})`
        : line.custom
          ? `${line.quantity}× ${line.custom.productName} (${line.custom.sizeOrVariant}) [custom]`
          : `${line.quantity}× ${line.productId}`
      return label
    })
    .join("\n")

  const categories = payload.categoryInterests
    .map(
      (c) =>
        `• ${c.categoryId}: ${c.importance}${c.preferredItems ? ` — wants: ${c.preferredItems}` : ""}`,
    )
    .join("\n")

  const subject = `Essenvia field survey · ${payload.salesRep.name} (${payload.salesRep.code}) · ${payload.boxPlan}`

  const text = [
    `New Essenvia household survey`,
    ``,
    `Survey ID: ${payload.id}`,
    `Submitted: ${payload.submittedAt}`,
    ``,
    `Sales rep: ${payload.salesRep.name} · Code: ${payload.salesRep.code}`,
    `Box plan: ${payload.boxPlan}`,
    ``,
    `Household: ${payload.household.size}`,
    `Laundry loads: ${payload.household.laundryLoads}`,
    `Dishwasher loads: ${payload.household.dishwasherLoads}`,
    `Detergent: ${payload.household.detergentFormat} · Brand: ${payload.household.laundryBrand}`,
    `Restock pace: ${payload.household.restockPace}`,
    ``,
    `Basket (${payload.menuItems.length} lines):`,
    menuLines || "— none —",
    ``,
    `Other categories:`,
    categories || "— none —",
    ``,
    payload.customerNotes ? `Customer notes:\n${payload.customerNotes}` : "",
    payload.talkTrack?.repNotes ? `Rep notes:\n${payload.talkTrack.repNotes}` : "",
    ``,
    `Full JSON payload is stored in Postgres (surveys.payload_json).`,
  ]
    .filter(Boolean)
    .join("\n")

  const html = `
    <h2>New Essenvia field survey</h2>
    <p><strong>ID:</strong> ${payload.id}<br/>
    <strong>Submitted:</strong> ${payload.submittedAt}</p>
    <p><strong>Rep:</strong> ${escapeHtml(payload.salesRep.name)} · ${escapeHtml(payload.salesRep.code)}<br/>
    <strong>Box:</strong> ${escapeHtml(payload.boxPlan)}</p>
    <h3>Household & loads</h3>
    <ul>
      <li>Size: ${escapeHtml(payload.household.size)}</li>
      <li>Laundry: ${escapeHtml(payload.household.laundryLoads)}</li>
      <li>Dishwasher: ${escapeHtml(payload.household.dishwasherLoads)}</li>
      <li>Detergent: ${escapeHtml(payload.household.detergentFormat)} · ${escapeHtml(payload.household.laundryBrand)}</li>
      <li>Pace: ${escapeHtml(payload.household.restockPace)}</li>
    </ul>
    <h3>Basket</h3>
    <pre>${escapeHtml(menuLines || "—")}</pre>
    <h3>Other categories</h3>
    <pre>${escapeHtml(categories || "—")}</pre>
    ${payload.customerNotes ? `<h3>Customer notes</h3><p>${escapeHtml(payload.customerNotes)}</p>` : ""}
    ${payload.talkTrack?.repNotes ? `<h3>Rep notes</h3><p>${escapeHtml(payload.talkTrack.repNotes)}</p>` : ""}
  `

  return { subject, text, html }
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
}

/** Sends summary to careers@essenvia.ca (or SURVEY_NOTIFY_TO) via Resend when RESEND_API_KEY is set. */
export async function notifySurveySubmitted(payload: SurveyPayload): Promise<NotifyResult> {
  const apiKey = process.env.RESEND_API_KEY?.trim()
  if (!apiKey) {
    return {
      sent: false,
      reason:
        "Email not configured. Add RESEND_API_KEY in Vercel env and verify sender domain (or use Resend onboarding address).",
    }
  }

  const from =
    process.env.RESEND_FROM?.trim() || "Essenvia Surveys <onboarding@resend.dev>"
  const { subject, text, html } = formatSurveyEmail(payload)

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: [notifyTo()],
      subject,
      text,
      html,
    }),
  })

  const body = (await res.json().catch(() => ({}))) as { id?: string; message?: string }
  if (!res.ok) {
    return {
      sent: false,
      reason: body.message ?? `Resend HTTP ${res.status}`,
    }
  }

  return { sent: true, provider: "resend", messageId: body.id }
}
