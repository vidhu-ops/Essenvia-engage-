"use client"

import { Check } from "lucide-react"
import { cn } from "@/lib/utils"

export function OptionGrid({
  options,
  value,
  onChange,
  columns = 2,
}: {
  options: string[]
  value: string
  onChange: (v: string) => void
  columns?: 1 | 2 | 3
}) {
  return (
    <div
      className={cn(
        "grid gap-2",
        columns === 1 && "grid-cols-1",
        columns === 2 && "sm:grid-cols-2",
        columns === 3 && "sm:grid-cols-2 lg:grid-cols-3",
      )}
    >
      {options.map((option) => (
        <button
          key={option}
          type="button"
          onClick={() => onChange(option)}
          className={cn(
            "field-touch-option flex items-center gap-3 rounded-xl border bg-white p-4 text-left text-base transition-colors hover:border-[var(--essenvia-teal)]",
            value === option && "border-[var(--essenvia-teal)] ring-2 ring-[var(--essenvia-teal)]/30",
          )}
        >
          <span
            className={cn(
              "flex h-6 w-6 shrink-0 items-center justify-center rounded-full border",
              value === option && "border-[var(--essenvia-teal)] bg-[var(--essenvia-teal)] text-white",
            )}
          >
            {value === option && <Check className="h-3.5 w-3.5" />}
          </span>
          {option}
        </button>
      ))}
    </div>
  )
}
