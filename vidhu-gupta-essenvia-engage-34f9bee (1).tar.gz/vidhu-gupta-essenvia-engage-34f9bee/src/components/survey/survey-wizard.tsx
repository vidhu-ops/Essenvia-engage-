"use client"

import { useCallback, useEffect, useMemo, useState, type FormEventHandler } from "react"
import Link from "next/link"
import { ArrowLeft, ArrowRight } from "lucide-react"
import Image from "next/image"
import { CategoryShop } from "@/components/survey/category-shop"
import { OptionGrid } from "@/components/survey/option-grid"
import { CUSTOM_LINE_IMAGE, getProductPackImage } from "@/data/product-images"
import { BoxCalculatorTable } from "@/components/box-calculator-table"
import { buttonVariants } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import {
  catalogueById,
  recommendPlan,
  boxPlans,
  type BoxPlanId,
} from "@/data/catalogue"
import { surveyCategoryTopics } from "@/data/survey-categories"
import type { CategoryInterest, MenuLine, ProductAnswer } from "@/types/survey"
import { cn } from "@/lib/utils"

const STEP_LABELS = ["Household & plan", "Shop by category", "Review", "Finish"] as const

const SHOP_STEP = 1
const REVIEW_STEP = 2
const FINISH_STEP = 3

function emptyCategoryInterests(): CategoryInterest[] {
  return surveyCategoryTopics.map((t) => ({ categoryId: t.id, importance: "" }))
}

const SCRIPT_STORAGE_PREFIX = "essenvia-talk-track:"

const householdOptions = ["Just me", "2 people", "3–4 people", "5+ people"]
export function SurveyWizard() {
  const [step, setStep] = useState(0)
  const [household, setHousehold] = useState("3–4 people")
  const [laundryLoads, setLaundryLoads] = useState("4–6 loads")
  const [detergentFormat, setDetergentFormat] = useState("Pods")
  const [laundryBrand, setLaundryBrand] = useState("Tide")
  const [dishwasherLoads, setDishwasherLoads] = useState("4–6 loads")
  const [restockPace, setRestockPace] = useState("Typical")
  const [boxPlan, setBoxPlan] = useState<BoxPlanId>("standard")
  const [menuItems, setMenuItems] = useState<MenuLine[]>([])
  const [productAnswers, setProductAnswers] = useState<ProductAnswer[]>([])
  const [search, setSearch] = useState("")
  const [customerNotes, setCustomerNotes] = useState("")
  const [repName, setRepName] = useState("")
  const [repCode, setRepCode] = useState("")
  const [scriptText, setScriptText] = useState("")
  const [scriptFilename, setScriptFilename] = useState<string | undefined>()
  const [repNotes, setRepNotes] = useState("")
  const [scriptSaved, setScriptSaved] = useState(false)
  const [categoryInterests, setCategoryInterests] = useState<CategoryInterest[]>(
    emptyCategoryInterests,
  )
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState("")
  const [submitSuccess, setSubmitSuccess] = useState<string | null>(null)

  const recommended = useMemo(() => recommendPlan(household), [household])
  const activePlan = boxPlans.find((p) => p.id === boxPlan)!
  const progress = ((step + 1) / STEP_LABELS.length) * 100

  const menuProducts = menuItems
    .map((line) => ({
      line,
      product: catalogueById.get(line.productId) ?? null,
      custom: line.custom,
    }))
    .filter((x) => x.product || x.custom)

  const syncRecommendedPlan = useCallback(() => {
    setBoxPlan(recommendPlan(household))
  }, [household])

  const goNext = useCallback(() => {
    if (step === SHOP_STEP) {
      setCategoryInterests((prev) =>
        prev.map((c) =>
          c.importance.trim() ? c : { ...c, importance: "Not discussed on visit" },
        ),
      )
      setProductAnswers((prev) =>
        prev.map((a) => ({
          ...a,
          usage: a.usage ?? "Weekly",
          satisfaction: a.satisfaction ?? "Not currently using",
          priority: a.priority ?? "Nice to have",
        })),
      )
    }
    if (step === 0) {
      setBoxPlan(recommendPlan(household))
    }
    setSubmitError("")
    setStep((s) => Math.min(s + 1, STEP_LABELS.length - 1))
  }, [household, step])

  const goBack = useCallback(() => {
    setSubmitError("")
    setStep((s) => Math.max(s - 1, 0))
  }, [])

  const onWizardFormSubmit: FormEventHandler<HTMLFormElement> = useCallback(
    (e) => {
      e.preventDefault()
      if (step < STEP_LABELS.length - 1) goNext()
    },
    [goNext, step],
  )

  function addToMenu(productId: string) {
    setMenuItems((prev) => {
      const existing = prev.find((m) => m.productId === productId)
      if (existing) {
        return prev.map((m) =>
          m.productId === productId ? { ...m, quantity: m.quantity + 1 } : m,
        )
      }
      return [...prev, { productId, quantity: 1 }]
    })
    setProductAnswers((prev) => {
      if (prev.some((a) => a.productId === productId)) return prev
      return [...prev, { productId }]
    })
  }

  function addShowcaseToMenu(payload: {
    category: string
    productName: string
    brand?: string
    sizeOrVariant: string
    notes?: string
  }) {
    setSubmitError("")
    const existing = menuItems.find((m) => m.custom?.notes === payload.notes)
    if (existing) {
      adjustQty(existing.productId, 1)
      return
    }
    const productId = `custom-${crypto.randomUUID()}`
    const custom = {
      category: payload.category,
      productName: payload.productName,
      brand: payload.brand,
      sizeOrVariant: payload.sizeOrVariant,
      notes: payload.notes,
    }
    setMenuItems((prev) => [...prev, { productId, quantity: 1, custom }])
    setProductAnswers((prev) => [...prev, { productId, usage: "Weekly", priority: "Nice to have" }])
  }

  function setCategoryField(
    categoryId: string,
    field: keyof Omit<CategoryInterest, "categoryId">,
    value: string,
  ) {
    setCategoryInterests((prev) =>
      prev.map((c) => (c.categoryId === categoryId ? { ...c, [field]: value } : c)),
    )
  }

  function adjustQty(productId: string, delta: number) {
    setMenuItems((prev) => {
      const next = prev
        .map((m) =>
          m.productId === productId
            ? { ...m, quantity: Math.max(0, m.quantity + delta) }
            : m,
        )
        .filter((m) => m.quantity > 0)
      return next
    })
    if (delta < 0 && !menuItems.some((m) => m.productId === productId && m.quantity + delta > 0)) {
      setProductAnswers((prev) => prev.filter((a) => a.productId !== productId))
    }
  }

  const persistScriptLocally = useCallback((code: string, text: string, filename?: string) => {
    if (!code.trim()) return
    try {
      localStorage.setItem(
        `${SCRIPT_STORAGE_PREFIX}${code.trim()}`,
        JSON.stringify({ text, filename, updatedAt: new Date().toISOString() }),
      )
    } catch {
      /* ignore quota */
    }
  }, [])

  useEffect(() => {
    const code = repCode.trim()
    if (!code || step !== FINISH_STEP) return
    const local = localStorage.getItem(`${SCRIPT_STORAGE_PREFIX}${code}`)
    if (local) {
      try {
        const parsed = JSON.parse(local) as { text?: string; filename?: string }
        if (parsed.text) setScriptText(parsed.text)
        if (parsed.filename) setScriptFilename(parsed.filename)
      } catch {
        /* ignore */
      }
    }
    void fetch(`/api/rep-scripts?code=${encodeURIComponent(code)}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.found && data.scriptText) {
          setScriptText(data.scriptText)
          setScriptFilename(data.scriptFilename ?? undefined)
        }
      })
      .catch(() => undefined)
  }, [repCode, step])

  function onScriptFileSelected(file: File | null) {
    if (!file) return
    if (file.size > 512_000) {
      setSubmitError("Script file must be under 512 KB.")
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      setScriptText(String(reader.result ?? ""))
      setScriptFilename(file.name)
      setSubmitError("")
    }
    reader.readAsText(file)
  }

  async function saveScriptOnly() {
    const code = repCode.trim()
    if (!code) {
      setSubmitError("Enter your sales code on the next step, or type it here first.")
      return
    }
    persistScriptLocally(code, scriptText, scriptFilename)
    try {
      await fetch("/api/rep-scripts", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          repCode: code,
          scriptText,
          scriptFilename,
        }),
      })
      setScriptSaved(true)
      setTimeout(() => setScriptSaved(false), 2500)
    } catch {
      setSubmitError("Could not save script to server; it is stored in this browser.")
    }
  }

  async function submitSurvey() {
    setSubmitError("")
    if (!repName.trim() || !repCode.trim()) {
      setSubmitError("Enter your name and sales code to submit.")
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch("/api/surveys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          household: {
            size: household,
            laundryLoads,
            detergentFormat,
            laundryBrand,
            dishwasherLoads,
            restockPace,
          },
          boxPlan,
          menuItems,
          productAnswers,
          categoryInterests: categoryInterests.filter((c) => c.importance.trim()),
          customerNotes: customerNotes.trim() || undefined,
          talkTrack: {
            scriptText: scriptText.trim() || undefined,
            scriptFilename,
            repNotes: repNotes.trim() || undefined,
          },
          salesRep: { name: repName.trim(), code: repCode.trim() },
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        const detail = data.details?.fieldErrors
          ? JSON.stringify(data.details.fieldErrors)
          : data.details?.join?.(", ")
        throw new Error(detail || data.error || "Submission failed")
      }
      persistScriptLocally(repCode.trim(), scriptText, scriptFilename)
      setSubmitSuccess(data.id)
    } catch (e) {
      setSubmitError(e instanceof Error ? e.message : "Submission failed")
    } finally {
      setSubmitting(false)
    }
  }

  if (submitSuccess) {
    return (
      <Card className="mx-auto max-w-lg border-[var(--essenvia-teal)]/30">
        <CardHeader>
          <CardTitle className="text-2xl">Survey saved</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            This household survey was recorded successfully. Reference ID:{" "}
            <code className="rounded bg-muted px-2 py-0.5 text-sm">{submitSuccess}</code>
          </p>
          <div className="flex flex-wrap gap-2">
            <Link href="/" className={buttonVariants({ variant: "outline" })}>
              Back to landing
            </Link>
            <button
              type="button"
              className={buttonVariants()}
              onClick={() => {
                setSubmitSuccess(null)
                setStep(0)
                setMenuItems([])
                setProductAnswers([])
                setCategoryInterests(emptyCategoryInterests())
                setRepName("")
                setRepCode("")
                setCustomerNotes("")
                setScriptText("")
                setScriptFilename(undefined)
                setRepNotes("")
              }}
            >
              Start another survey
            </button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div
      className={cn(
        "survey-wizard-shell mx-auto pb-6",
        step === SHOP_STEP ? "max-w-6xl" : "max-w-4xl",
      )}
    >
      <div className="builder-progress mb-6 rounded-full overflow-hidden">
        <i style={{ width: `${progress}%` }} />
      </div>
      <div className="space-y-2 mb-6">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>
            Step {step + 1} of {STEP_LABELS.length}: {STEP_LABELS[step]}
          </span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      <form
        className="survey-wizard-form rounded-xl ring-1 ring-foreground/10 bg-card text-card-foreground border-[var(--essenvia-sage)]/40 shadow-md overflow-visible"
        onSubmit={onWizardFormSubmit}
        noValidate
      >
        <CardContent className="survey-wizard-body pt-4 sm:pt-6 space-y-5 sm:space-y-6 pb-2 px-3 sm:px-(--card-spacing)">
          {step === 0 && (
            <>
              <div>
                <p className="text-sm font-medium text-[var(--essenvia-teal)]">Start</p>
                <h2 className="survey-step-title mt-1">Household & Essenvia plan</h2>
                <p className="text-muted-foreground mt-2">
                  Pick the box size, then you&apos;ll shop every category with photos in one place.
                </p>
              </div>
              <div>
                <Label className="mb-2 block">Who are we stocking up for?</Label>
                <OptionGrid options={householdOptions} value={household} onChange={setHousehold} />
              </div>
              <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 pt-2">
                <div>
                  <p className="text-sm text-muted-foreground">
                    Recommended:{" "}
                    <strong>{boxPlans.find((p) => p.id === recommended)?.retailName}</strong>
                  </p>
                </div>
                <button
                  type="button"
                  className={buttonVariants({ variant: "secondary", size: "sm" })}
                  onClick={syncRecommendedPlan}
                >
                  Apply recommendation
                </button>
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                {boxPlans.map((plan) => (
                  <button
                    key={plan.id}
                    type="button"
                    onClick={() => setBoxPlan(plan.id)}
                    className={cn(
                      "rounded-xl border bg-white p-4 text-left",
                      boxPlan === plan.id && "border-[var(--essenvia-teal)] ring-2 ring-[var(--essenvia-teal)]/30",
                    )}
                  >
                    <p className="font-semibold">{plan.retailName}</p>
                    <p className="text-2xl mt-1">${plan.priceCad.toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">{plan.productRange}</p>
                  </button>
                ))}
              </div>
              <BoxCalculatorTable selectedPlan={boxPlan} onSelectPlan={setBoxPlan} interactive />
            </>
          )}

          {step === SHOP_STEP && (
            <CategoryShop
              boxLabel={activePlan.retailName}
              menuItems={menuItems}
              onAdd={addToMenu}
              onAdjustQty={adjustQty}
              onAddShowcase={addShowcaseToMenu}
              search={search}
              onSearchChange={setSearch}
              laundryLoads={laundryLoads}
              onLaundryLoads={setLaundryLoads}
              detergentFormat={detergentFormat}
              onDetergentFormat={setDetergentFormat}
              laundryBrand={laundryBrand}
              onLaundryBrand={setLaundryBrand}
              dishwasherLoads={dishwasherLoads}
              onDishwasherLoads={setDishwasherLoads}
              restockPace={restockPace}
              onRestockPace={setRestockPace}
              categoryInterests={categoryInterests}
              onCategoryImportance={(topicId, value) =>
                setCategoryField(topicId, "importance", value)
              }
            />
          )}

          {step === REVIEW_STEP && (
            <>
              <div>
                <p className="text-sm font-medium text-[var(--essenvia-teal)]">Review</p>
                <h2 className="survey-step-title mt-1">Confirm the box</h2>
                <p className="text-muted-foreground mt-2">
                  {household} · {laundryLoads} laundry · {dishwasherLoads} kitchen · {activePlan.retailName}
                </p>
              </div>
              {menuProducts.length === 0 ? (
                <p className="text-muted-foreground rounded-xl border p-4 bg-muted/30">
                  No products added yet — go back to shop, or submit if you only discussed the standard
                  box.
                </p>
              ) : (
                <div className="ecom-product-grid">
                  {menuProducts.map(({ line, product, custom }) => (
                    <div
                      key={line.productId}
                      className="flex gap-3 rounded-xl border bg-white p-3 col-span-2 sm:col-span-1"
                    >
                      <div className="relative h-20 w-20 shrink-0 rounded-lg overflow-hidden">
                        <Image
                          src={product ? getProductPackImage(product) : CUSTOM_LINE_IMAGE}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="80px"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm line-clamp-2">
                          {custom
                            ? custom.productName
                            : `${product!.brand} ${product!.name}`}
                        </p>
                        <p className="text-xs text-muted-foreground">Qty {line.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div>
                <Label htmlFor="customer-notes">Customer notes (optional)</Label>
                <Textarea
                  id="customer-notes"
                  rows={3}
                  value={customerNotes}
                  onChange={(e) => setCustomerNotes(e.target.value)}
                  placeholder="Delivery, scents, allergies…"
                />
              </div>
            </>
          )}

          {step === FINISH_STEP && (
            <>
              <div>
                <p className="text-sm font-medium text-[var(--essenvia-teal)]">Finish</p>
                <h2 className="survey-step-title mt-1">Rep details & submit</h2>
              </div>
              <div className="rounded-xl bg-muted/50 p-4 text-sm space-y-1">
                <p>
                  <strong>{activePlan.retailName}</strong> · {menuItems.length} line
                  {menuItems.length === 1 ? "" : "s"} in box
                </p>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rep-name">Your full name</Label>
                  <Input
                    id="rep-name"
                    required
                    value={repName}
                    onChange={(e) => setRepName(e.target.value)}
                    placeholder="Alex Morgan"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rep-code">Sales code</Label>
                  <Input
                    id="rep-code"
                    required
                    value={repCode}
                    onChange={(e) => setRepCode(e.target.value)}
                    placeholder="REP-1024"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="script-text">Talk track (optional)</Label>
                <Textarea
                  id="script-text"
                  rows={4}
                  value={scriptText}
                  onChange={(e) => setScriptText(e.target.value)}
                  placeholder="Opening script for this visit…"
                />
              </div>
              {submitError && (
                <p className="text-sm text-destructive" role="alert">
                  {submitError}
                </p>
              )}
            </>
          )}
        </CardContent>
        <div
          className="survey-wizard-nav sticky bottom-0 z-30 flex flex-wrap sm:flex-nowrap items-center justify-between gap-3 sm:gap-4 border-t bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 p-3 sm:p-4 rounded-b-xl"
          role="navigation"
          aria-label="Survey steps"
        >
          {step === 0 ? (
            <Link href="/" className={cn(buttonVariants({ variant: "ghost" }), "survey-nav-btn")}>
              <ArrowLeft className="h-4 w-4" /> Exit
            </Link>
          ) : (
            <button
              type="button"
              className={cn(buttonVariants({ variant: "outline" }), "survey-nav-btn")}
              onClick={goBack}
              data-testid="survey-back"
            >
              <ArrowLeft className="h-4 w-4" /> Back
            </button>
          )}
          {step < STEP_LABELS.length - 1 ? (
            <button
              type="button"
              className={cn(buttonVariants(), "survey-nav-btn survey-nav-btn-primary ml-auto")}
              onClick={goNext}
              data-testid="survey-continue"
            >
              Continue <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button
              type="button"
              className={cn(buttonVariants(), "survey-nav-btn survey-nav-btn-primary ml-auto")}
              disabled={submitting}
              onClick={() => void submitSurvey()}
              data-testid="survey-submit"
            >
              {submitting ? "Saving…" : "Submit survey"}
            </button>
          )}
        </div>
      </form>
    </div>
  )
}
