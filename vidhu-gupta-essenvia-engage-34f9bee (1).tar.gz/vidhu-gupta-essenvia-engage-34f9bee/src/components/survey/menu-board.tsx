"use client"

import Image from "next/image"
import { ChevronDown, Minus, Plus, Search, ShoppingBasket, Sparkles } from "lucide-react"
import { useMemo, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { buttonVariants } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  catalogueById,
  type CatalogueProduct,
} from "@/data/catalogue"
import {
  type CatalogueMenuCategory,
  countInCategory,
  productsInCategory,
} from "@/data/catalogue-groups"
import { ProductSpecCard } from "@/components/survey/product-spec-card"
import { catalogueSearchBlob } from "@/lib/product-specs"
import { essenviaHowItWorks } from "@/data/essenvia-how-it-works"
import {
  CUSTOM_LINE_IMAGE,
  getCategoryPhoto,
  getProductPackImage,
} from "@/data/product-images"
import {
  customMenuCategoryOptions,
  type CustomMenuCategory,
} from "@/data/survey-categories"
import type { MenuLine } from "@/types/survey"
import { cn } from "@/lib/utils"

type MenuBoardProps = {
  boxLabel: string
  menuItems: MenuLine[]
  search: string
  onSearchChange: (v: string) => void
  onAdd: (productId: string) => void
  onAdjustQty: (productId: string, delta: number) => void
  customCategory: CustomMenuCategory
  onCustomCategoryChange: (c: CustomMenuCategory) => void
  customBrand: string
  onCustomBrandChange: (v: string) => void
  customName: string
  onCustomNameChange: (v: string) => void
  customSize: string
  onCustomSizeChange: (v: string) => void
  customNotes: string
  onCustomNotesChange: (v: string) => void
  onAddCustom: () => void
  formError?: string
  /** One catalogue category per wizard step — every SKU shown with specs. */
  lockedCategory: CatalogueMenuCategory
  stepTitle: string
  stepDescription: string
  showEssenviaIntro?: boolean
  loadsSummary?: string
}

function BasketLine({
  line,
  onAdjust,
}: {
  line: MenuLine
  onAdjust: (delta: number) => void
}) {
  const product = catalogueById.get(line.productId)
  const img = product ? getProductPackImage(product) : CUSTOM_LINE_IMAGE
  const title = product
    ? `${product.brand} ${product.name}`
    : line.custom?.productName ?? "Custom item"
  const sub = product
    ? product.netQuantity
    : line.custom?.sizeOrVariant

  return (
    <li className="flex gap-3 items-center py-2 border-b border-[var(--sand)] last:border-0">
      <div className="relative h-12 w-12 shrink-0 rounded-lg bg-[var(--cream)] overflow-hidden">
        <Image src={img} alt="" fill className="object-contain p-1" sizes="48px" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate">{title}</p>
        <p className="text-xs text-muted-foreground truncate">{sub}</p>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <button
          type="button"
          aria-label="Decrease"
          className={buttonVariants({ size: "icon", variant: "ghost", className: "h-7 w-7" })}
          onClick={() => onAdjust(-1)}
        >
          <Minus className="h-3 w-3" />
        </button>
        <span className="w-6 text-center text-sm font-semibold tabular-nums">{line.quantity}</span>
        <button
          type="button"
          aria-label="Increase"
          className={buttonVariants({ size: "icon", variant: "ghost", className: "h-7 w-7" })}
          onClick={() => onAdjust(1)}
        >
          <Plus className="h-3 w-3" />
        </button>
      </div>
    </li>
  )
}

export function MenuBoard(props: MenuBoardProps) {
  const {
    boxLabel,
    menuItems,
    search,
    onSearchChange,
    onAdd,
    onAdjustQty,
    customCategory,
    onCustomCategoryChange,
    customBrand,
    onCustomBrandChange,
    customName,
    onCustomNameChange,
    customSize,
    onCustomSizeChange,
    customNotes,
    onCustomNotesChange,
    onAddCustom,
    formError,
    lockedCategory,
    stepTitle,
    stepDescription,
    showEssenviaIntro = false,
    loadsSummary,
  } = props

  const [howOpen, setHowOpen] = useState(showEssenviaIntro)
  const [customOpen, setCustomOpen] = useState(false)

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase()
    return productsInCategory(lockedCategory).filter((p) => !q || catalogueSearchBlob(p).includes(q))
  }, [search, lockedCategory])

  const basketCount = menuItems.reduce((n, m) => n + m.quantity, 0)
  const categoryHeaderPhoto = getCategoryPhoto(lockedCategory)
  const skuCount = countInCategory(lockedCategory)

  return (
    <div className="menu-board-layout">
      <div className="menu-board-main space-y-4">
        {showEssenviaIntro && (
          <div className="rounded-2xl border border-[var(--essenvia-sage)]/50 bg-[var(--cream)] overflow-hidden">
            <button
              type="button"
              className="flex w-full items-center justify-between gap-3 p-4 text-left"
              onClick={() => setHowOpen((o) => !o)}
            >
              <div className="flex items-start gap-3">
                <Sparkles className="h-5 w-5 shrink-0 text-[var(--essenvia-teal)] mt-0.5" />
                <div>
                  <p className="font-semibold">{essenviaHowItWorks.headline}</p>
                  <p className="text-sm text-muted-foreground mt-0.5">{essenviaHowItWorks.subline}</p>
                </div>
              </div>
              <ChevronDown
                className={cn("h-5 w-5 shrink-0 transition-transform", howOpen && "rotate-180")}
              />
            </button>
            {howOpen && (
              <ul className="grid sm:grid-cols-2 gap-3 px-4 pb-4 text-sm">
                {essenviaHowItWorks.points.map((p) => (
                  <li key={p.title} className="rounded-xl bg-white/80 p-3 border border-white">
                    <p className="font-medium text-[var(--essenvia-teal)]">{p.title}</p>
                    <p className="text-muted-foreground mt-1 leading-relaxed">{p.body}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-[var(--essenvia-teal)]">{lockedCategory}</p>
            <h2 className="survey-step-title mt-1">{stepTitle}</h2>
            <p className="text-base sm:text-sm text-muted-foreground mt-1 leading-relaxed">{stepDescription}</p>
            <p className="text-sm text-muted-foreground mt-2 leading-snug">
              All <strong>{skuCount}</strong> verified {lockedCategory.toLowerCase()} sizes in the catalogue
              · Box: <strong>{boxLabel}</strong>
              {loadsSummary ? ` · ${loadsSummary}` : ""}
            </p>
          </div>
          <div className="relative w-full sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9 survey-field-input"
              placeholder="Search brand or size…"
              value={search}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
        </div>

        <div className="relative h-24 sm:h-28 rounded-2xl overflow-hidden">
          <Image
            src={categoryHeaderPhoto}
            alt=""
            fill
            className="object-cover"
            sizes="(max-width: 768px) 100vw, 720px"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent flex items-center px-5">
            <p className="text-white font-semibold text-lg">{lockedCategory} — every pack size</p>
          </div>
        </div>

        <div className="menu-spec-list space-y-4">
          {filteredProducts.map((p) => {
            const inMenu = menuItems.find((m) => m.productId === p.id)
            return (
              <ProductSpecCard
                key={p.id}
                product={p}
                quantity={inMenu?.quantity ?? 0}
                onAdd={() => onAdd(p.id)}
                onAdjust={(d) => onAdjustQty(p.id, d)}
              />
            )
          })}
        </div>

        <div className="rounded-2xl border border-dashed border-[var(--sand)] bg-white">
          <button
            type="button"
            className="flex w-full items-center justify-between p-4 text-left"
            onClick={() => setCustomOpen((o) => !o)}
          >
            <div className="flex items-center gap-3">
              <div className="relative h-12 w-12 rounded-lg bg-[var(--cream)]">
                <Image src={CUSTOM_LINE_IMAGE} alt="" fill className="object-contain p-1" />
              </div>
              <div>
                <p className="font-medium">Special order — another {lockedCategory} size</p>
                <p className="text-xs text-muted-foreground">Log a pack size or variant not listed below</p>
              </div>
            </div>
            <ChevronDown className={cn("h-5 w-5", customOpen && "rotate-180")} />
          </button>
          {customOpen && (
            <div className="px-4 pb-4 space-y-3 border-t pt-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <p className="text-sm text-muted-foreground sm:col-span-2">
                  Category: <strong>{lockedCategory}</strong>
                </p>
                <div className="space-y-2">
                  <Label htmlFor="menu-custom-brand">Brand</Label>
                  <Input
                    id="menu-custom-brand"
                    value={customBrand}
                    onChange={(e) => onCustomBrandChange(e.target.value)}
                    placeholder="Optional"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="menu-custom-name">Product</Label>
                  <Input
                    id="menu-custom-name"
                    value={customName}
                    onChange={(e) => onCustomNameChange(e.target.value)}
                    placeholder="Toilet paper…"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="menu-custom-size">Size / count</Label>
                  <Input
                    id="menu-custom-size"
                    value={customSize}
                    onChange={(e) => onCustomSizeChange(e.target.value)}
                    placeholder="24 rolls, 591 mL…"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="menu-custom-notes">Notes (optional)</Label>
                  <Input
                    id="menu-custom-notes"
                    value={customNotes}
                    onChange={(e) => onCustomNotesChange(e.target.value)}
                    placeholder="Scent-free, brand swap…"
                  />
                </div>
              </div>
              <button type="button" className={buttonVariants()} onClick={onAddCustom}>
                Add special order to basket
              </button>
              {formError && (
                <p className="text-sm text-destructive" role="alert">
                  {formError}
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      <aside className="menu-board-basket" aria-label="Customer basket">
        <div className="sticky top-4 rounded-2xl border bg-white shadow-sm overflow-hidden">
          <div className="bg-[var(--essenvia-teal)] text-white px-4 py-3 flex items-center gap-2">
            <ShoppingBasket className="h-5 w-5" />
            <div className="flex-1">
              <p className="font-semibold">Basket</p>
              <p className="text-xs opacity-90">{boxLabel}</p>
            </div>
            <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-sm font-bold tabular-nums">
              {basketCount}
            </span>
          </div>
          <div className="max-h-[min(420px,50vh)] overflow-y-auto px-3">
            {menuItems.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground px-2">
                No items yet — tap products on the menu to start the order.
              </p>
            ) : (
              <ul>
                {menuItems.map((line) => (
                  <BasketLine
                    key={line.productId}
                    line={line}
                    onAdjust={(d) => onAdjustQty(line.productId, d)}
                  />
                ))}
              </ul>
            )}
          </div>
          {menuItems.length > 0 && (
            <p className="text-xs text-muted-foreground px-4 py-3 border-t">
              {menuItems.length} line{menuItems.length === 1 ? "" : "s"} · Continue when the basket
              matches what you discussed.
            </p>
          )}
        </div>
      </aside>
    </div>
  )
}

