# Where Essenvia Engage lives (no GitHub until you mirror)

This project was built in a **Cursor Cloud Agent** session. The **canonical source** is **Cursor Origin**, not GitHub—unless you create a mirror (below).

## Links you can open today

| What | URL |
|------|-----|
| **Browse code in Cursor** | https://cursor.com/codebase/vidhu-gupta/essenvia-engage |
| **Git remote (Origin)** | `https://origin.cursor.com/git/vidhu-gupta/essenvia-engage.git` |
| **Production app (Cursor Publish)** | https://essenvia-survey.apps.grok.bot |
| **Survey path** | https://essenvia-survey.apps.grok.bot/survey |
| **This agent run (history)** | https://cursor.com/agents/bc-75edea5a-bd49-42bd-918b-839145081851 |

**Vercel:** If you claimed a Vercel project earlier, open [vercel.com/dashboard](https://vercel.com/dashboard) → your **essenvia** project → **Deployments** → **Redeploy** (code on Origin `main` is up to date; connect Git when you have a mirror).

There is **no** `github.com/vidhu-gupta/essenvia-engage` until you create it.

**Origin mirror status:** `no-mirror` (checked via `origin repo view --json mirrorStatus`).

---

## Option A — Create a GitHub repo from Cursor (required for Vercel Git)

1. Open [this codebase](https://cursor.com/codebase/vidhu-gupta/essenvia-engage) or this agent chat.
2. Click **Create repo** (creates `essenvia-engage` on GitHub and mirrors from Origin).
3. **Vercel** → [Import Project](https://vercel.com/new) → GitHub → **essenvia-engage** → **Deploy**.
4. Add **Storage → Postgres** and the env vars from the table below → **Redeploy**.

Product images are **per-SKU pack art** in `public/images/products/skus/` (run `npm run enhance:sku-art` to regenerate). Replace any `.svg` with real pack photography when you have assets.

---

## Option B — Create GitHub yourself and push

On [github.com/new](https://github.com/new): name **`essenvia-engage`**, private, **no** README.

On your laptop (with GitHub login):

```bash
git clone https://origin.cursor.com/git/vidhu-gupta/essenvia-engage.git
cd essenvia-engage
git remote add github git@github.com:YOUR_USERNAME/essenvia-engage.git
git push -u github main
```

Then import that repo in Vercel and add env vars (same names as Cursor Publish secrets).

---

## Option C — Vercel without GitHub

From a machine where you run `vercel login`:

```bash
git clone https://origin.cursor.com/git/vidhu-gupta/essenvia-engage.git
cd essenvia-engage
npm install
npx vercel link          # pick your claimed project
npx vercel deploy --prod
```

Add **Postgres** (Storage) and copy **RESEND_***, **SURVEY_***, **SURVEYS_ADMIN_TOKEN** in Vercel → Settings → Environment Variables.

---

## Environment variables (Vercel or Cursor Publish)

| Variable | Purpose |
|----------|---------|
| `POSTGRES_URL` / `DATABASE_URL` | Auto from Vercel Postgres, or Neon |
| `RESEND_API_KEY` | Survey emails |
| `RESEND_FROM` | Sender |
| `SURVEY_NOTIFY_TO` | Inbox |
| `SURVEYS_ADMIN_TOKEN` | `GET /api/surveys` bearer token |

Cursor Publish already binds these for **essenvia-survey.apps.grok.bot**; mirror the same names on Vercel for parity.
