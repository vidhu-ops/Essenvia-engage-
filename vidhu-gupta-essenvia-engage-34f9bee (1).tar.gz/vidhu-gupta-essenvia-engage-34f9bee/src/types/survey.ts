import type { BoxPlanId } from "@/data/catalogue"

export type ProductAnswer = {
  productId: string
  usage?: string
  satisfaction?: string
  priority?: string
  notes?: string
}

export type CustomMenuDetail = {
  category: string
  productName: string
  brand?: string
  sizeOrVariant: string
  notes?: string
}

export type MenuLine = {
  productId: string
  quantity: number
  custom?: CustomMenuDetail
}

export type CategoryInterest = {
  categoryId: string
  importance: string
  currentProducts?: string
  preferredItems?: string
  notes?: string
}

export type TalkTrack = {
  scriptText?: string
  scriptFilename?: string
  repNotes?: string
}

export type SurveyPayload = {
  id: string
  submittedAt: string
  household: {
    size: string
    laundryLoads: string
    detergentFormat: string
    laundryBrand: string
    dishwasherLoads: string
    restockPace: string
  }
  boxPlan: BoxPlanId
  menuItems: MenuLine[]
  productAnswers: ProductAnswer[]
  categoryInterests: CategoryInterest[]
  customerNotes?: string
  talkTrack?: TalkTrack
  salesRep: {
    name: string
    code: string
  }
}
