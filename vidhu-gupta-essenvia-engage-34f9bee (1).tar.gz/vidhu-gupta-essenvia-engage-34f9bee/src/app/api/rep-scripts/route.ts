import { NextResponse } from "next/server"
import { z } from "zod"
import {
  getRepScript,
  upsertRepScript,
  DatabaseNotConfiguredError,
} from "@/lib/db"

const bodySchema = z.object({
  repCode: z.string().trim().min(2).max(64),
  scriptText: z.string().max(50000),
  scriptFilename: z.string().max(255).optional(),
})

export async function GET(request: Request) {
  const code = new URL(request.url).searchParams.get("code")?.trim()
  if (!code) {
    return NextResponse.json({ error: "Missing code query param" }, { status: 400 })
  }
  try {
    const script = await getRepScript(code)
    if (!script) {
      return NextResponse.json({ found: false })
    }
    return NextResponse.json({ found: true, ...script })
  } catch (e) {
    if (e instanceof DatabaseNotConfiguredError) {
      return NextResponse.json({ error: e.message }, { status: 503 })
    }
    return NextResponse.json({ error: "Failed to load script" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  let raw: unknown
  try {
    raw = await request.json()
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 })
  }
  const parsed = bodySchema.safeParse(raw)
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 },
    )
  }
  try {
    await upsertRepScript(
      parsed.data.repCode,
      parsed.data.scriptText,
      parsed.data.scriptFilename,
    )
    return NextResponse.json({ ok: true })
  } catch (e) {
    if (e instanceof DatabaseNotConfiguredError) {
      return NextResponse.json({ error: e.message }, { status: 503 })
    }
    return NextResponse.json({ error: "Failed to save script" }, { status: 500 })
  }
}
