#!/usr/bin/env node
/**
 * Prints the surveys admin bearer token from Postgres (app_settings).
 * Requires POSTGRES_URL or DATABASE_URL in the environment.
 */
import postgres from "postgres"

const url =
  process.env.POSTGRES_URL ??
  process.env.DATABASE_URL ??
  process.env.POSTGRES_URL_NON_POOLING

if (!url) {
  console.error("Set POSTGRES_URL or DATABASE_URL to read the admin token.")
  process.exit(1)
}

const sql = postgres(url, {
  ssl: url.includes("localhost") ? false : "require",
  prepare: false,
})

const fromEnv = process.env.SURVEYS_ADMIN_TOKEN?.trim()
if (fromEnv) {
  console.log(fromEnv)
  console.error("(from SURVEYS_ADMIN_TOKEN environment variable)")
  await sql.end()
  process.exit(0)
}

const rows = await sql`
  SELECT value FROM app_settings WHERE key = 'surveys_admin_token' LIMIT 1
`
await sql.end()

if (!rows[0]?.value) {
  console.error(
    "No token in database yet. Call GET /api/surveys once after deploy (with Resend configured) to auto-provision and email careers@essenvia.ca.",
  )
  process.exit(2)
}

console.log(rows[0].value)
