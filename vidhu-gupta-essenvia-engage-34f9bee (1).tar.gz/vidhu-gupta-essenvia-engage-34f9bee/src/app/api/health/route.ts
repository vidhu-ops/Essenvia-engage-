import { NextResponse } from "next/server"
import { getStorageBackend, pingDatabase, DatabaseNotConfiguredError } from "@/lib/db"

export async function GET() {
  const backend = getStorageBackend()
  if (backend === "unconfigured") {
    return NextResponse.json(
      {
        status: "degraded",
        database: "unconfigured",
        message:
          "Add Vercel Postgres (Neon) from Project → Storage, or set POSTGRES_URL / DATABASE_URL.",
      },
      { status: 503 },
    )
  }
  try {
    await pingDatabase()
    return NextResponse.json({
      status: "ok",
      database: "postgres",
      timestamp: new Date().toISOString(),
    })
  } catch (e) {
    const message = e instanceof Error ? e.message : "Database ping failed"
    return NextResponse.json(
      { status: "error", database: "postgres", message },
      { status: 503 },
    )
  }
}
