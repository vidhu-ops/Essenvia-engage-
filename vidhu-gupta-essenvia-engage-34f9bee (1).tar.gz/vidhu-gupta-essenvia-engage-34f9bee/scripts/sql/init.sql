-- Run automatically on first API use (idempotent).
CREATE TABLE IF NOT EXISTS surveys (
  id TEXT PRIMARY KEY,
  submitted_at TIMESTAMPTZ NOT NULL,
  rep_name TEXT NOT NULL,
  rep_code TEXT NOT NULL,
  box_plan TEXT NOT NULL,
  payload_json JSONB NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_surveys_submitted_at ON surveys (submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_surveys_rep_code ON surveys (rep_code);

CREATE TABLE IF NOT EXISTS rep_scripts (
  rep_code TEXT PRIMARY KEY,
  script_text TEXT NOT NULL,
  script_filename TEXT,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
